package com.ssafy.live.washer;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ssafy.live.washer.beans.SWasher;
import com.ssafy.live.washer.beans.WasherUser;
import com.ssafy.live.washer.conf.WasherConfig;

public class WasherTest {

    ApplicationContext ctx;
    
    @BeforeEach
    public void setup() {
        ctx = new AnnotationConfigApplicationContext(WasherConfig.class);
    }
    
    @Test
    public void washerTest() {
        WasherUser user = ctx.getBean(WasherUser.class);
        Assertions.assertNotNull(user);
        user.useWasher("socks");
    }
    
    @Test
    public void washerBeanTest() {
        WasherUser user = ctx.getBean(WasherUser.class);
        SWasher sWasher = ctx.getBean(SWasher.class);
        Assertions.assertSame(user.getWasher(), sWasher);
    }
}
