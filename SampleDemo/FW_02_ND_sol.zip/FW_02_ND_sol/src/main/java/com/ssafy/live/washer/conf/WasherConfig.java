package com.ssafy.live.washer.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ssafy.live.washer.beans.LWasher;
import com.ssafy.live.washer.beans.SWasher;
import com.ssafy.live.washer.beans.WasherUser;

@Configuration
public class WasherConfig {

    @Bean
    public SWasher sWasher() {
        return new SWasher();
    }

    @Bean
    public LWasher lWasher() {
        return new LWasher();
    }

    @Bean("myWasherUser")
    public WasherUser washerUser() {
        //return new WasherUser(sWasher());
        WasherUser user = new WasherUser();
        user.setWasher(sWasher());
        return user;
    }
}
