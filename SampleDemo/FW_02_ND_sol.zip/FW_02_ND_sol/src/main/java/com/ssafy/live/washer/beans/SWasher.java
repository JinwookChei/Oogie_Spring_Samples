package com.ssafy.live.washer.beans;

public class SWasher implements Washer{

    public void wash(String clothes) {
        System.out.println(clothes + " 세탁을 시작합니다.");
    }
}
