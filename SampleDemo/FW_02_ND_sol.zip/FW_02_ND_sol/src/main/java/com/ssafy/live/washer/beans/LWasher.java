package com.ssafy.live.washer.beans;

public class LWasher implements Washer {

    public void wash(String clothes) {
        System.out.println(clothes + " 세탁을 시작합니다.");
    }
}
