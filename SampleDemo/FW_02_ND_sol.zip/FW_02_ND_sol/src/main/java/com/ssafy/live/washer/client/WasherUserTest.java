package com.ssafy.live.washer.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ssafy.live.washer.beans.SWasher;
import com.ssafy.live.washer.beans.Washer;
import com.ssafy.live.washer.beans.WasherUser;
import com.ssafy.live.washer.conf.WasherConfig;

public class WasherUserTest {

    public static void main(String[] args) {
       ApplicationContext ctx = new AnnotationConfigApplicationContext(WasherConfig.class);
       
       WasherUser user = ctx.getBean(WasherUser.class);
       user.useWasher("sweater");
       
       Washer sWasher = ctx.getBean(SWasher.class);
       System.out.println(user.getWasher()==sWasher);
       
       Washer washer = ctx.getBean("sWasher", Washer.class);
       System.out.println(washer==sWasher);
       

    }

}
