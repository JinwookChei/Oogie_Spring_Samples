package com.ssafy.live.washer.beans;

public class WasherUser {
    Washer washer;
    
    public WasherUser() {}
    
    public WasherUser(Washer washer) {
        this.washer = washer;
    }

    public void useWasher(String clothes){
        washer.wash(clothes);
    }
    
    public void setWasher(Washer washer) {
        this.washer = washer;
    }
    
    public Washer getWasher() {
        return this.washer;
    }
}
