package com.ssafy.live.bag.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.ssafy.live.accessory")
public class BagConfig {

}
