package com.ssafy.live.bag.beans;

import org.springframework.stereotype.Component;

@Component
public class Hat {

}
