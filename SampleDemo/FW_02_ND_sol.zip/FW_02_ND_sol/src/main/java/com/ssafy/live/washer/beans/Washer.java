package com.ssafy.live.washer.beans;

public interface Washer {

    void wash(String clothes);
}
