package com.ssafy.live.washer.conf;

import com.ssafy.live.washer.beans.WasherUser;

public class WasherUserTest     {
    public static void main(String[] args) {
        WasherFactory factory = new WasherFactory();
        WasherUser user = new WasherUser(factory.createWasher("S"));
        user.useWasher("바지");
    }
}
