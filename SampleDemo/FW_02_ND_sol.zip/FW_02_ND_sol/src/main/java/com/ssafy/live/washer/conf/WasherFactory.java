package com.ssafy.live.washer.conf;

import com.ssafy.live.washer.beans.LWasher;
import com.ssafy.live.washer.beans.SWasher;
import com.ssafy.live.washer.beans.Washer;

public class WasherFactory {
    public Washer createWasher(String type){
        if(type.equals("L")){
            return new LWasher();
        }else if(type.equals("S")){
            return new SWasher();
        }else{
            return null;
        }
    }
}
