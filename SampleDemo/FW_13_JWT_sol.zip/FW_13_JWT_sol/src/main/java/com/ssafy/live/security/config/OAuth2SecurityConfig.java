package com.ssafy.live.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.http.SessionCreationPolicy;

import com.ssafy.live.security.handler.OAuth2LoginSuccessHandler;
import com.ssafy.live.security.handler.OAuth2LoginFailureHandler;
import com.ssafy.live.security.service.CustomOAuth2UserService;

import lombok.RequiredArgsConstructor;

// TODO: 17-1. "/login/oauth2/**", "/oauth2/**" 경로에 대한 시큐리티 설정을 확인하세요.
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class OAuth2SecurityConfig {

        private final OAuth2LoginSuccessHandler oAuth2LoginSuccessHandler;
        private final OAuth2LoginFailureHandler oAuth2LoginFailureHandler;
        private final CustomOAuth2UserService customOAuth2UserService;

        @Bean
        @Order(0) // 우선순위를 높여 JWT API 시큐리티보다 소셜 로그인이 먼저 가로채도록 설정
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
                http.securityMatcher("/login/oauth2/**", "/oauth2/**") // 소셜 로그인 관련 경로만 가로채도록 범위 축소
                                .csrf(csrf -> csrf.disable()) // CSRF 미사용
                                .formLogin(form -> form.disable()) // 기본 로그인 폼 미사용
                                .httpBasic(basic -> basic.disable()) // 기본 HTTP 인증 미사용

                                // 중요: 리다이렉트 및 성공 핸들러 처리 완료시까지 시큐리티 세션을 보장하기 위해 ALWAYS 정책 지정
                                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.ALWAYS))

                                .authorizeHttpRequests(auth -> auth
                                                .requestMatchers("/login/oauth2/**", "/oauth2/**").permitAll() // 해당 경로는 인증 없이 접근 가능
                                                .anyRequest().authenticated())

                                // 핵심: OAuth2 로그인 기능 활성화 및 커스텀 컴포넌트 장착
                                .oauth2Login(oauth2 -> oauth2
                                                .userInfoEndpoint(userInfo -> userInfo.userService(customOAuth2UserService))
                                                .successHandler(oAuth2LoginSuccessHandler)
                                                .failureHandler(oAuth2LoginFailureHandler));

                return http.build();
        }
}
