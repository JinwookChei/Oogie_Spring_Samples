package com.ssafy.live.config;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.JwtException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class RestExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleRestException(Exception e) {
        log.error("[@RestController에서 발생한 오류] ", e);
        return ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    }

    // TODO: 09-2. JwtException이 발생하면 401(unauthorized)로 처리하자.
    @ExceptionHandler(JwtException.class)
    public ProblemDetail handleJwtException(JwtException e) {
        log.error("[JWT 검증 오류] {}", e.getMessage());
        return ProblemDetail.forStatusAndDetail(HttpStatus.UNAUTHORIZED, e.getMessage());
    }
}
