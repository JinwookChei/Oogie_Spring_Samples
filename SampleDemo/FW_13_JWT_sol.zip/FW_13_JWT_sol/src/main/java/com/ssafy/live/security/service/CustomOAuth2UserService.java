package com.ssafy.live.security.service;

import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;
import com.ssafy.live.security.dto.CustomUserDetails;
import com.ssafy.live.security.dto.GithubUserInfo;
import com.ssafy.live.security.dto.OAuth2UserInfo;

import lombok.RequiredArgsConstructor;

// TODO: 15-1. DefaultOAuth2UserService를 상속받아 소셜 로그인을 처리할 CustomOAuth2UserService 클래스를 확인하세요.
// loadUser()에서 super.loadUser()를 호출해서 사용자 정보를 취득 후 UserDetails를 구성/반환한다.
@Service
@RequiredArgsConstructor
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private final MemberService memberService;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        // 1. 기본 유저 정보 로드 (GitHub 등 Authentication Server로부터 사용자 정보를 가져옴)
        OAuth2User oAuth2User = super.loadUser(userRequest);

        // 2. 어떤 소셜 서비스인지 확인 (github, google, kakao 등)
        String provider = userRequest.getClientRegistration().getRegistrationId();

        // 3. 서비스에 맞게 데이터를 추출할 DTO 생성 (Switch Expression)
        OAuth2UserInfo oAuth2UserInfo = switch (provider) {
        case "github" -> new GithubUserInfo(oAuth2User.getAttributes());
        default -> throw new OAuth2AuthenticationException("Unsupported provider: " + provider);
        };

        // 4. 추출한 정보로 DB에 연동된 소셜 계정이 있는지 조회 (없으면 임시 GUEST 생성)
        String providerId = oAuth2UserInfo.getProviderId();

        Member member = null;
        try {
            // DB에 연동된 소셜 계정이 있는지 조회
            member = memberService.loginBySocial(provider, providerId);
        } catch (Exception e) {
            // 연동된 계정이 없는 경우: 임시 GUEST 회원 객체 생성, GUEST 권한 부여로 USER와 구별
            member = Member.builder()
                    .email(provider + "_" + providerId + "@social.temp") // principalName 검증 통과를 위해 임시 고유 이메일 지정
                    .name(oAuth2UserInfo.getName())
                    .password("")
                    .role("GUEST") // GUEST 권한 부여로 식별
                    .build();
        }

        // 5. 일반 로그인과 동일하게 CustomUserDetails 타입으로 통일하여 반환
        return new CustomUserDetails(member, oAuth2User.getAttributes());
    }
}
