package com.ssafy.live.restcontroller;

import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/etc")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "EtcRestController", description = "기타 유틸리티성 기능 제공")
public class EtcRestController {

        @GetMapping("/bingimage")
        @Operation(summary = "빙 바탕화면 조회", description = "빙 바탕화면 정보 조회")
        public ResponseEntity<?> bingImage() {

                UriComponentsBuilder builder = UriComponentsBuilder
                                .fromUriString("https://www.bing.com/HPImageArchive.aspx")
                                .queryParam("format", "js")
                                .queryParam("idx", "0")
                                .queryParam("n", "1")
                                .queryParam("mkt", "ko-KR")
                                .encode();

                RestClient client = RestClient.create(builder.toUriString());
                Map<String, Object> resultMap = client.get() // Http Method 별 처리
                                .retrieve() // 요청
                                .body(new ParameterizedTypeReference<Map<String, Object>>() {
                                });// 결과 포멧
                return ResponseEntity.ok(resultMap);
        }
}
