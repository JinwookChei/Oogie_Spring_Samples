package com.ssafy.live.security.dto;

import java.util.Map;
import java.util.Optional;

// TODO: 14-2. Github OAuth정보를 담을 DTO 클래스를 확인하세요.
// google 등 여러 provider에 대응하기 위해 OAuth2UserInfo 인터페이스를 구현
public class GithubUserInfo implements OAuth2UserInfo {
    private final Map<String, Object> attributes;

    public GithubUserInfo(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String getProviderId() {
        return String.valueOf(attributes.get("id"));
    }

    @Override
    public String getProvider() {
        return "github";
    }

    @Override
    public String getEmail() {
        // GitHub는 이메일이 public이 아닌 경우 null일 수 있음
        return (String) attributes.get("email");
    }

    @Override
    public String getName() {
        return (String) Optional.ofNullable(attributes.get("name")).orElse(attributes.get("login"));
    }
}
