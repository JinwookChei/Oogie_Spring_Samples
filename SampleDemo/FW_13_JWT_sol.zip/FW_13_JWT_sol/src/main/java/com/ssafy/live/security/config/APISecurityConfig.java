package com.ssafy.live.security.config;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.model.service.MemberService;
import com.ssafy.live.security.filter.JWTAuthenticationFilter;
import com.ssafy.live.security.filter.JWTVerificationFilter;
import com.ssafy.live.security.filter.SecurityExceptionHandlingFilter;
import com.ssafy.live.security.service.CustomUserDetailsService;

import lombok.RequiredArgsConstructor;
import tools.jackson.databind.ObjectMapper;

@Configuration
@RequiredArgsConstructor
public class APISecurityConfig {

        private final CustomUserDetailsService userDetailsService;
        private final MemberService memberService;
        private final JWTUtil jwtUtil;
        private final ObjectMapper objectMapper;

        // TODO: 06-1. Spring Security 5.4 이상에서 AuthenticationManager를 Bean으로 사용하려면 명시적 등록 필요
        @Bean
        AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig)
                        throws Exception {
                return authConfig.getAuthenticationManager();
        }

        @Bean
        @Order(1) // 낮을 수록 우선순위가 높음. 생략 시 가장 낮음
        SecurityFilterChain apiSecurityFilterChain(HttpSecurity http, AuthenticationManager authenticationManager)
                        throws Exception {

                // TODO: 06-2. SecurityFilterChain을 구성한다.
                // 이 filter chain은 /api/**를 대상으로 하며 cors, userdetails, csrf, session
                // 관련 설정을 해보자.
                http.securityMatcher("/api/**") // SecurityFilterChain의 동작 범위 설정
                                .userDetailsService(userDetailsService)
                                .cors(Customizer.withDefaults()) // 컨텍스트의 CorsConfigurationSource를 자동 적용
                                .csrf(csrf -> csrf.disable())// Csrf 설정 무력화
                                .sessionManagement(// 세션 설정 - 세션 사용하지 않음
                                                session -> session.sessionCreationPolicy(
                                                                SessionCreationPolicy.STATELESS));
                //  /api/v1/public/**, /api/v1/etc/**, /api/v1/auth/** 경로는 permitall 하고 나머지는 인증을 요청한다.
                // 단, 소셜 연동(/api/v1/auth/social-link)은 로그인이 필요한 기능이므로 인증 필수
                http.authorizeHttpRequests(authorize -> authorize
                                .requestMatchers("/api/v1/auth/social-link").authenticated()
                                // 바로 통과시킬 경로 설정
                                .requestMatchers("/api/v1/etc/**", "/api/v1/public/**", "/api/v1/auth/**").permitAll() // 인증불필요
                                .anyRequest().authenticated());
                //  filter들을 직접 생성하고 적절한 위치/순서를 지정한다.
                JWTAuthenticationFilter authFilter = new JWTAuthenticationFilter(authenticationManager, memberService, jwtUtil, objectMapper);
                JWTVerificationFilter verifyFilter = new JWTVerificationFilter(jwtUtil, userDetailsService);
                SecurityExceptionHandlingFilter exceptionFilter = new SecurityExceptionHandlingFilter(objectMapper);

                http.addFilterAt(authFilter, UsernamePasswordAuthenticationFilter.class)
                                .addFilterBefore(verifyFilter, JWTAuthenticationFilter.class)
                                .addFilterBefore(exceptionFilter, JWTVerificationFilter.class);
                return http.build();
        }

        // TODO: 06-3. Filter 수준에서 동작하기 위한 CorsConfigurationSource를 구성하고 적용하자.
        // WebMvcConfigurer는 cors 설정은 무의미. 왜냐하면 Filter단계에서 이미 차단되기 때문.
        @Bean
        CorsConfigurationSource corsConfigurationSource() {
                CorsConfiguration configuration = new CorsConfiguration();
                configuration.setAllowedOrigins(Arrays.asList("*"));
                configuration.setAllowedMethods(
                                Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"));
                configuration.setAllowedHeaders(Arrays.asList("*"));

                UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
                source.registerCorsConfiguration("/api/**", configuration);
                source.registerCorsConfiguration("/member/checkEmail", configuration);

                return source;
        }
}
