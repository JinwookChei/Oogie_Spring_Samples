package com.ssafy.live.security.handler;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;
import com.ssafy.live.security.dto.CustomUserDetails;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

// TODO: 15-2. SimpleUrlAuthenticationSuccessHandler를 상속받아 OAuth2LoginSuccessHandler 클래스를 생성하세요.
// 소셜 로그인 성공 시 JWT 토큰을 발행하고 프론트엔드로 리다이렉트 경로를 구성한다.
@Component
@RequiredArgsConstructor
@Slf4j
public class OAuth2LoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

  private final JWTUtil jwtUtil;
  private final MemberService memberService;

  @Override
  public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
      Authentication authentication) throws IOException, ServletException {
    log.debug("인증 성공: {}", authentication);
    CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
    Member member = userDetails.getMember();

    // ROLE에 따라 적절한 리다이렉트 URL 생성
    String targetUrl = switch (member.getRole()) {
    case "GUEST" -> getUrlForGuest(authentication, userDetails, member);
    default -> getUrlForUser(member);
    };

    log.debug("targetUrl: {}", targetUrl);
    getRedirectStrategy().sendRedirect(request, response, targetUrl);
  }

  // 1. ROLE이 GUEST면 아직 연동 안됨 - 클라이언트에서 다시 연동 확인 절차 필요
  private String getUrlForGuest(Authentication authentication, CustomUserDetails userDetails, Member member) {
    String provider = ((OAuth2AuthenticationToken) authentication).getAuthorizedClientRegistrationId();
    String providerId = String.valueOf(userDetails.getAttributes().get("id"));
    String encodedName = URLEncoder.encode(member.getName(), StandardCharsets.UTF_8);

    return "/#socialLinkNeeded=true&provider=%s&providerId=%s&nickname=%s"
        .formatted(provider, providerId, encodedName);
  }

  // 2. ROLE이 GUEST가 아니면(USER, ADMIN) - JWT 토큰 발행 및 Refresh 토큰 DB 저장
  private String getUrlForUser(Member member) {
    String accessToken = jwtUtil.createAccessToken(member);
    String refreshToken = jwtUtil.createRefreshToken(member);

    member.setRefresh(refreshToken);
    memberService.update(member);

    return "/#accessToken=%s&refreshToken=%s".formatted(accessToken, refreshToken);
  }

}
