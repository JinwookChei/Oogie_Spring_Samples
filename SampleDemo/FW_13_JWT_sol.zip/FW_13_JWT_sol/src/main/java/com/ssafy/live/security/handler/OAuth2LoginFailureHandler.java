package com.ssafy.live.security.handler;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

// TODO: 15-3. SimpleUrlAuthenticationFailureHandler를 상속받는 OAuth2LoginFailureHandler 클래스를 확인하세요.
// 소셜 로그인 실패 시 오류 메시지를 포함하여 프론트엔드로 리다이렉트한다.
@Component
@Slf4j
public class OAuth2LoginFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException exception) throws IOException, ServletException {

        log.error("[OAuth2LoginFailureHandler] 소셜 로그인 실패 발생: {}", exception.getMessage(), exception);

        // 예외 메시지의 한글 깨짐을 방지하기 위해 UTF-8 URL 인코딩 적용
        String encodedMsg = URLEncoder.encode(exception.getMessage(), StandardCharsets.UTF_8);

        // 프론트엔드 메인화면 해시파라미터(#socialError)로 에러 메시지 전달
        String targetUrl = "/#socialError=%s".formatted(encodedMsg);
        getRedirectStrategy().sendRedirect(request, response, targetUrl);
    }
}
