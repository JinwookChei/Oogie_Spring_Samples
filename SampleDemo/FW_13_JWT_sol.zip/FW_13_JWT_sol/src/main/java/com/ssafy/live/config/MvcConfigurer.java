package com.ssafy.live.config;
 
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
 
@Configuration
public class MvcConfigurer implements WebMvcConfigurer {
 
    @Value("${spring.servlet.multipart.location}")
    private String filePath;
 
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 업로드 파일 서비스 설정
        registry.addResourceHandler("/upload/**").addResourceLocations("file:" + filePath + "/");
        
        // 정적 리소스(index.html 등)는 스프링 부트 기본 설정으로 자동 서비스됨
    }
 
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
