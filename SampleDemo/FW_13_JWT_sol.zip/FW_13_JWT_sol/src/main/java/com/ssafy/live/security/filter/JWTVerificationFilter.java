package com.ssafy.live.security.filter;

import java.io.IOException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.filter.OncePerRequestFilter;
import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.security.service.CustomUserDetailsService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RequiredArgsConstructor
@Slf4j
public class JWTVerificationFilter extends OncePerRequestFilter {
    private final JWTUtil jwtUtil;
    private final CustomUserDetailsService userDetailsService;

    /**
     * Authorization 헤더에서 토큰을 추출한다.
     */
    private String extractToken(HttpServletRequest request) {
        // TODO: 04-1. Authorization 헤더가 'Bearer '로 시작하는지 확인하고, 'Bearer '를 제거한
        // 토큰을 반환한다.
        String token = request.getHeader("Authorization");
        if (token != null && token.startsWith("Bearer ")) {
            return token.substring(7);
        } else {
            return null;
        }
    }

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        // TODO: 04-2. JWT 토큰을 검증하고 인증 정보를 SecurityContextHolder에 저장한다.
        String token = extractToken(request);
        log.debug("access token: {}", token);
        //  01. 토큰이 있다면 검증(login 등 인증 토큰이 없는 요청은 인증을 하지 않음)
        if (token != null) {
            //  2. 토큰 검증 및 claim의 email로 사용자 정보(UserDetails) 조회
            //  토큰에 문제 없다면(clame 조회 시 예외 없음) 사용자 정보는 신뢰할만하다.
            Claims claims = jwtUtil.getClaims(token);
            log.debug("claims 확인: {}", claims);
            UserDetails userDetails = userDetailsService.loadUserByUsername(claims.get("email").toString());

            //  3. UsernamePasswordAuthenticationToken 생성 
            var authentication = UsernamePasswordAuthenticationToken.authenticated(userDetails, null,
                    userDetails.getAuthorities());
            //  4. SecurityContextHolder에 저장                    
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }

        //  4. 다음 filter로 요청을 전달
        filterChain.doFilter(request, response);
    }

}
