package com.ssafy.live.jwt;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ssafy.live.model.dto.Member;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JWTUtil {
    private final long accessExpMin;
    private final long refreshExpMin;
    private final SecretKey key;
    private final JwtParser jwtParser;

    public JWTUtil(@Value("${ssafy.jwt.access-expmin}") long accessExpMin,
            @Value("${ssafy.jwt.refresh-expmin}") long refreshExpMin,
            @Value("${ssafy.jwt.secret-string}") String secretKeyString) {
        this.accessExpMin = accessExpMin;
        this.refreshExpMin = refreshExpMin;
        this.key = Keys.hmacShaKeyFor(secretKeyString.getBytes(StandardCharsets.UTF_8));
        jwtParser = Jwts.parser().verifyWith(this.key).build();
        log.debug("jwt secret key: {}", Arrays.toString(key.getEncoded()));
    }

    public String createAccessToken(Member member) {
        // null 값을 직렬화 시킬 수 없다.
        String role = (member.getRole() != null) ? member.getRole() : "USER";

        return create("accessToken", accessExpMin, Map.of("email", member.getEmail(), "name",
                member.getName(), "role", role));
    }

    public String createRefreshToken(Member member) {
        return create("refreshToken", refreshExpMin, Map.of("email", member.getEmail()));
    }

    /**
     * JWT를 반환한다.
     * 
     * @param subject
     *            token의 제목(accessToken, refreshToken)
     * @param expireMin
     * @param member
     *            회원 정보
     * @return
     */
    public String create(String subject, long expireMin, Map<String, Object> claims) {

        Date expireDate = new Date(System.currentTimeMillis() + 1000 * 60 * expireMin);
        // TODO: 03-1. JWT를 생성해서 반환하세요.
        //  전달받은 subject, expireMin, claims를 사용하고 생성된 key로 서명한다.
        String jwt = Jwts.builder().subject(subject) // 제목 설정
                .claims(claims) // claim(key-value 쌍) 추가
                .expiration(expireDate) // 만료일 설정
                .signWith(key) // 서명 알고리즘 설정
                .compact(); // 직렬화 처리
        log.debug("{} 토큰 발행: {}", subject, jwt);

        return jwt;
    }

    /**
     * 토큰 검증 및 claim 정보 반환
     * 
     * @param jwt
     * @return
     * @throws ExpireJwtException:
     *             형식은 적합하지만 토큰의 유효기간이 지난 경우
     * @throws MalformedJwtException:
     *             형식이 잘못된 토큰을 이용하려는 경우
     * @throws SignatureException:
     *             훼손된 토큰을 이용하려는 경우
     */
    public Claims getClaims(String jwt) {
        // TODO: 03-2. JWT토큰을 검증하고 claim 정보를 반환하는 코드를 살펴보세요.
        // JWS: json web signature - json 형식으로 표현된 데이터에 대한 디지털 서명
        Jws<Claims> jws = jwtParser.parseSignedClaims(jwt);
        log.debug("claims : {}", jws);
        return jws.getPayload();
    }
}
