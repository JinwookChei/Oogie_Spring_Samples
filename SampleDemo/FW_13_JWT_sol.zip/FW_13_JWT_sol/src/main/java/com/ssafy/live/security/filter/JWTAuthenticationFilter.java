package com.ssafy.live.security.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import tools.jackson.databind.ObjectMapper;
import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;
import com.ssafy.live.security.dto.CustomUserDetails;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final MemberService memberService;
    private final JWTUtil jwtUtil;
    private final ObjectMapper objectMapper;

    // TODO: 05-1. 조상생성자를 호출 한다.
    // AuthenticationManager는 스프링 시큐리티가 빈으로 등록한 것을 주입 - 이 빈은 추가적으로 config에서 등록해야 함.
    public JWTAuthenticationFilter(AuthenticationManager authenticationManager,
            MemberService memberService, JWTUtil jwtUtil, ObjectMapper mapper) {
        super(authenticationManager);

        this.memberService = memberService;
        this.jwtUtil = jwtUtil;
        this.objectMapper = mapper;
        this.setFilterProcessesUrl("/api/v1/auth/login"); // 로그인 처리 URL 설정
        this.setUsernameParameter("email"); // email을 username으로 사용
        this.setPasswordParameter("password"); // password를 password로 사용
    }

    // 로그인 성공 시 실행하는 메소드 (JWT 발급)
    @Override
    public void successfulAuthentication(HttpServletRequest request, HttpServletResponse response,
            FilterChain chain, Authentication authentication) {
        Map<String, Object> result = new HashMap<>();

        // TODO: 05-2. Authentication의 정보를 활용해 accessToken을 발급하고 result map에 담는다.
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Member member = userDetails.getMember();
        String accessToken = jwtUtil.createAccessToken(member);
        //  token 전달
        result.put("accessToken", accessToken);
        // TODO: 08-1. refresh token을 발급받아서 DB에 저장하고 추가로 클라이언트에게 전달한다.
        String refreshToken = jwtUtil.createRefreshToken(member);
        member.setRefresh(refreshToken);
        memberService.update(member);
        result.put("refreshToken", refreshToken);
        handleResult(response, result, HttpStatus.OK);
    }

    // 로그인 실패 시 실행하는 메소드
    @Override
    public void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException failed) {
        // 예외 처리는 한 곳에서 처리하도록 전달
        throw failed;
    }

    // 결과 전송 helper 메소드
    private void handleResult(HttpServletResponse response, Map<String, ?> data,
            HttpStatus status) {
        response.setContentType("application/json;charset=UTF-8");
        try {
            String jsonResponse = objectMapper.writeValueAsString(data);
            response.setStatus(status.value());
            response.getWriter().write(jsonResponse);
        } catch (IOException e) {
            log.error("JSON 처리 실패", e);
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
    }
}
