package com.ssafy.live.security.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;

import io.jsonwebtoken.JwtException;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Slf4j
public class JWTController {

    private final JWTUtil jwtUtil;
    private final MemberService memberService;

    // TODO: 09-1. /api/v1/auth/refresh요청 처리를 위한 handler 메서드를 살펴보자.
    @PostMapping("/refresh")
    public ResponseEntity<?> refreshAccessToken(@RequestHeader("Refresh-Token") String refreshToken) {
        // 1. refresh token 기반으로 Member 조회
        Member member = validateAndGetMember(refreshToken);

        // 2. DB에 저장된 refresh token과 일치하는지 확인
        if (member == null || !refreshToken.equals(member.getRefresh())) {
            log.warn("Invalid or mismatched refresh token");
            throw new JwtException("Invalid refresh token");
        }

        // 3. 새 Access Token 생성
        String newAccessToken = jwtUtil.createAccessToken(member);

        // 4. Refresh Token Rotation: 새 Refresh Token 생성 및 DB 업데이트
        String newRefreshToken = jwtUtil.createRefreshToken(member);
        member.setRefresh(newRefreshToken);
        memberService.update(member);

        // 5. 새 토큰들을 응답으로 반환
        return ResponseEntity.ok(Map.of("accessToken", newAccessToken, "refreshToken", newRefreshToken));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Refresh-Token") String refreshToken) {
        // TODO: 11-1. /api/v1/auth/logout 요청 시 refresh token에 해당하는 사용자 정보를 조회해서 정보를 수정하자.
        Member member = validateAndGetMember(refreshToken);

        // DB에 있는 토큰과 일치할 때만 삭제 처리
        if (member != null && refreshToken.equals(member.getRefresh())) {
            member.setRefresh(null);
            memberService.update(member);
        }
        return ResponseEntity.ok(Map.of("accessToken", "", "refreshToken", ""));
    }

    // TODO: 12-1. Swagger 문서 노출을 위한 가짜 로그인 엔드포인트
    // 실제 로그인 처리는 JWTAuthenticationFilter가 가로채서 수행하므로 이 메서드는 실행되지 않음
    // Swagger UI상에 로그인 명세를 노출시켜 클라이언트 개발자가 토큰을 쉽게 발급받을 수 있도록 정의.
    @Operation(summary = "일반 로그인 (JWT 발급)", description = "이메일과 비밀번호로 로그인을 요청하여 Access Token과 Refresh Token 발급")
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> dummyLogin(
            @RequestParam(defaultValue = "admin@ssafy.com") String email,
            @RequestParam(defaultValue = "1234") String password) {
        return ResponseEntity.ok(Map.of("accessToken", "string", "refreshToken", "string"));
    }

    // TODO: 16-1. 소셜 연동 API 구현를 구현하세요.
    @PostMapping("/social-link")
    public ResponseEntity<?> socialLink(
            Authentication authentication,
            @RequestBody Map<String, String> body) {
        String provider = body.get("provider");
        String providerId = body.get("providerId");
        if (provider == null || providerId == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "provider / providerId 누락"));
        }

        memberService.linkSocialAccount(authentication.getName(), provider, providerId);
        return ResponseEntity.ok(Map.of("message", "소셜 연동 성공"));
    }

    /**
     * Refresh Token을 검증하고 해당하는 Member 객체를 반환하는 헬퍼 메서드
     */
    private Member validateAndGetMember(String refreshToken) {
        if (refreshToken == null || refreshToken.isBlank()) {
            throw new JwtException("Refresh token is required");
        }
        Map<String, Object> claims = jwtUtil.getClaims(refreshToken);
        String email = (String) claims.get("email");

        if (email == null) {
            throw new JwtException("Invalid refresh token: email claim missing");
        }
        return memberService.selectDetail(email);
    }
}
