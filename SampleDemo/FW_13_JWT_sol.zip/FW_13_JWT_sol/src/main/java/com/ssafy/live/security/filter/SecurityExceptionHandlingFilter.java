package com.ssafy.live.security.filter;

import java.io.IOException;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.databind.ObjectMapper;

@Slf4j
@RequiredArgsConstructor
// TODO: 05-3. 인증/인가 과정에서 발생하는 예외를 처리하는 필터를 참조하세요.

public class SecurityExceptionHandlingFilter extends OncePerRequestFilter {

    private final ObjectMapper objectMapper;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(request, response);
        } catch (JwtException e) { // JWT 관련 예외 처리
            log.debug("JWT 예외 발생: {}, {}", request.getRequestURI(), e.getMessage());
            setErrorResponse(response, HttpStatus.UNAUTHORIZED, "TOKEN_ERROR");
        } catch (BadCredentialsException e) { // 로그인 실패 관련 처리
            log.debug("로그인 실패: {}, {}", request.getRequestURI(), e.getMessage());
            setErrorResponse(response, HttpStatus.UNAUTHORIZED, e.getMessage());
        } catch (Exception e) { // 기타 예외 처리
            log.error("서버 내부 오류: {}, {}", request.getRequestURI(), e.getMessage(), e);
            setErrorResponse(response, HttpStatus.INTERNAL_SERVER_ERROR, "서버 내부 오류가 발생했습니다.");
        }
    }

    private void setErrorResponse(HttpServletResponse response, HttpStatus status, String message)
            throws IOException {
        log.debug("커스텀 필터에서 발생한 예외 처리: {}, {}", status, message);
        response.setStatus(status.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8");

        Map<String, Object> errorDetails = Map.of("status", status.value(), "message", message);
        response.getWriter().write(objectMapper.writeValueAsString(errorDetails));
    }
}
