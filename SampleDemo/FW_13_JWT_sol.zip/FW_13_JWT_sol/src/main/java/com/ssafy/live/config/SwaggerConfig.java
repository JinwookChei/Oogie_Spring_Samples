package com.ssafy.live.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

@Configuration

// TODO: 12-2. 보안 옵션을 추가하기 위한 추가 어노테이션을 확인하세요..
// security 속성: API 전역에 JWT 보안 요구사항 적용(요처 시 마다 Bearer 토큰 전송)
@OpenAPIDefinition(info = @Info(title = "SSAFY HRM API 명세서", description = "API 명세서 테스트 입니다.", version = "v1"), security = @SecurityRequirement(name = "BearerAuth"))

// @SecurityScheme: 토큰 입력을 위한 버튼 등 UI 구성
@SecurityScheme(name = "BearerAuth", type = SecuritySchemeType.HTTP, scheme = "bearer", bearerFormat = "JWT")

public class SwaggerConfig {

    @Bean
    GroupedOpenApi memberApi() {
        String[] paths = { "/api/v1/members/**" };
        return GroupedOpenApi.builder().group("Member 관련 API").pathsToMatch(paths).build();
    }

    @Bean
    GroupedOpenApi publicOpenApi() {
        String[] paths = { "/api/v1/public/**", "/api/v1/auth/login" };
        return GroupedOpenApi.builder().group("공개 API").pathsToMatch(paths).build();
    }

    @Bean
    GroupedOpenApi otherOpenApi() {
        String[] paths = { "/api/v1/etc/**" };
        return GroupedOpenApi.builder().group("기타 API").pathsToMatch(paths).build();
    }
}
