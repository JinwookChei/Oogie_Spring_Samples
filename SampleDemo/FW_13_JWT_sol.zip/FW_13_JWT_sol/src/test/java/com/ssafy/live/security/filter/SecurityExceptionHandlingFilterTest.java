package com.ssafy.live.security.filter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.BadCredentialsException;

import io.jsonwebtoken.JwtException;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import tools.jackson.databind.ObjectMapper;

class SecurityExceptionHandlingFilterTest {

    private SecurityExceptionHandlingFilter filter;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;

    @BeforeEach
    void setUp() {
        filter = new SecurityExceptionHandlingFilter(new ObjectMapper());
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
    }

    @Test
    @DisplayName("정상 요청은 그대로 체인 통과")
    void doFilter_Success() throws ServletException, IOException {
        MockFilterChain filterChain = new MockFilterChain();

        // When
        filter.doFilter(request, response, filterChain);

        // Then
        assertNotNull(filterChain.getRequest(), "필터 체인이 호출되어야 합니다.");
    }

    @Test
    @DisplayName("JwtException 발생 시 401 UNAUTHORIZED 응답")
    void doFilter_JwtException() throws ServletException, IOException {
        // Given
        MockFilterChain filterChain = new MockFilterChain() {
            @Override
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                throw new JwtException("Invalid token");
            }
        };

        // When
        filter.doFilter(request, response, filterChain);

        // Then
        assertEquals(HttpStatus.UNAUTHORIZED.value(), response.getStatus());
        assertTrue(response.getContentAsString().contains("TOKEN_ERROR"));
    }

    @Test
    @DisplayName("BadCredentialsException 발생 시 401 UNAUTHORIZED 응답")
    void doFilter_BadCredentialsException() throws ServletException, IOException {
        // Given
        MockFilterChain filterChain = new MockFilterChain() {
            @Override
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                throw new BadCredentialsException("Invalid password");
            }
        };

        // When
        filter.doFilter(request, response, filterChain);

        // Then
        assertEquals(HttpStatus.UNAUTHORIZED.value(), response.getStatus());
        assertTrue(response.getContentAsString().contains("Invalid password"));
    }

    @Test
    @DisplayName("기타 예외 발생 시 500 INTERNAL_SERVER_ERROR 응답")
    void doFilter_OtherException() throws ServletException, IOException {
        // Given
        MockFilterChain filterChain = new MockFilterChain() {
            @Override
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                throw new RuntimeException("Unknown error");
            }
        };

        // When
        filter.doFilter(request, response, filterChain);

        // Then
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
        assertTrue(response.getContentAsString().contains("서버 내부 오류가 발생했습니다."));
    }
}
