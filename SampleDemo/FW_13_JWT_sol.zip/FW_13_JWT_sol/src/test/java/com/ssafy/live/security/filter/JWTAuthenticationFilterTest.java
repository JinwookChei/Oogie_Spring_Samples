package com.ssafy.live.security.filter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;

import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;
import com.ssafy.live.security.dto.CustomUserDetails;

import tools.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class JWTAuthenticationFilterTest {
    ObjectMapper mapper = new ObjectMapper();

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private MemberService memberService;

    @Mock
    private JWTUtil jwtUtil;

    @Mock
    private Authentication authentication;

    private JWTAuthenticationFilter filter;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private MockFilterChain filterChain;

    @BeforeEach
    void setUp() {
        filter = new JWTAuthenticationFilter(authenticationManager, memberService, jwtUtil, mapper);
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        filterChain = new MockFilterChain();
    }

    @Test
    @DisplayName("인증 성공 시 JWT 토큰 발급 및 응답 (refreshToken 저장)")
    void successfulAuthentication() throws Exception {
        // Given
        Member member = new Member();
        member.setEmail("test@ssafy.com");

        CustomUserDetails userDetails = new CustomUserDetails(member);
        when(authentication.getPrincipal()).thenReturn(userDetails);
        when(jwtUtil.createAccessToken(member)).thenReturn("access-token");
        when(jwtUtil.createRefreshToken(member)).thenReturn("refresh-token");

        // When
        filter.successfulAuthentication(request, response, filterChain, authentication);

        // Then
        verify(memberService).update(member);
        assertEquals("refresh-token", member.getRefresh());

        assertEquals(200, response.getStatus());
        assertTrue(response.getContentAsString().contains("access-token"));
        assertTrue(response.getContentAsString().contains("refresh-token"));
    }

    @Test
    @DisplayName("인증 실패 시 예외 던짐")
    void unsuccessfulAuthentication() {
        // Given
        BadCredentialsException exception = new BadCredentialsException("Bad credentials");

        // When & Then
        assertThrows(BadCredentialsException.class, () -> {
            filter.unsuccessfulAuthentication(request, response, exception);
        });
    }
}
