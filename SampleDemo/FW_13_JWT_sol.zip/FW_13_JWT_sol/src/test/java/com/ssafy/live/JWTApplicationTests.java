package com.ssafy.live;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Commit;

import com.ssafy.live.model.dao.MemberDao;

@SpringBootTest
class JWTApplicationTests {

    @Autowired
    PasswordEncoder pe;

    @Autowired
    MemberDao mdao;

    @Test
    void updatePass() {
        String pass = pe.encode("1234");
        mdao.searchAll().forEach(m -> {
            if (m.getPassword().equals("1234")) {
                // 1. 비밀번호 전용 메서드 호출
                mdao.updatePassword(m.getEmail(), pass);
                // 2. role도 업데이트가 필요하다면 기존 update 호출
                if (m.getRole() == null || m.getRole().isEmpty()) {
                    m.setRole("USER");
                    mdao.update(m);
                }
                System.out.println("비밀번호 변경 완료: " + m.getEmail());
            } else {
                System.out.println("이미 변경된 사용자: " + m.getEmail() + " : " + m.getPassword());
            }
        });
    }
}
