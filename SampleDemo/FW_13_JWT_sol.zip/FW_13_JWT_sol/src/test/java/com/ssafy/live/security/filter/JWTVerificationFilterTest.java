package com.ssafy.live.security.filter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.ssafy.live.jwt.JWTUtil;
import com.ssafy.live.security.service.CustomUserDetailsService;

import io.jsonwebtoken.Claims;
import jakarta.servlet.ServletException;

// TODO: 04-3. Spring과 무관하게 JWTVerificationFilter를 테스트하는 코드를 살펴보세요.
@ExtendWith(MockitoExtension.class)
class JWTVerificationFilterTest {

    @Mock
    private JWTUtil jwtUtil;

    @Mock
    private CustomUserDetailsService userDetailsService;

    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private MockFilterChain filterChain;

    private JWTVerificationFilter filter;
    private UserDetails userDetails;

    @BeforeEach
    void setUp() {
        filter = new JWTVerificationFilter(jwtUtil, userDetailsService);
        SecurityContextHolder.clearContext();

        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        filterChain = new MockFilterChain();

        userDetails = new User(
                "admin@ssafy.com",
                "1234",
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")));
    }

    @Test
    @DisplayName("유효한 토큰인 경우 인증 성공")
    void shouldAuthenticateValidToken() throws ServletException, IOException {
        // Given
        String token = "valid.jwt.token";
        request.addHeader("Authorization", "Bearer " + token);

        Map<String, Object> claims = new HashMap<>();
        claims.put("email", "admin@ssafy.com");
        Claims jwtClaims = new io.jsonwebtoken.impl.DefaultClaims(claims);
        when(jwtUtil.getClaims(token)).thenReturn(jwtClaims);
        when(userDetailsService.loadUserByUsername("admin@ssafy.com")).thenReturn(userDetails);

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        assertNotNull(filterChain.getRequest(), "필터 체인이 호출되어야 합니다.");
        assertNotNull(SecurityContextHolder.getContext().getAuthentication());
        assertEquals("admin@ssafy.com", SecurityContextHolder.getContext().getAuthentication().getName());
    }

    @Test
    @DisplayName("Authentication이 없는 경우 예외 발생 (인증 실패)")
    void shouldRejectMissingToken() throws ServletException, IOException {
        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        assertNull(SecurityContextHolder.getContext().getAuthentication());
        assertNotNull(filterChain.getRequest(), "인증이 없더라도 필터 체인은 통과해야 합니다.");
    }
}
