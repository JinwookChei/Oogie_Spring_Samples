package com.ssafy.live.ai.config;

import java.util.stream.Collectors;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.chat.memory.repository.jdbc.JdbcChatMemoryRepository;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.google.genai.GoogleGenAiChatOptions;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.io.Resource;

import com.google.genai.Client;
import com.google.genai.types.HttpOptions;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class AiConfiguration {

    @Value("${spring.ai.google.genai.api-key}")
    private String genAiApiKey;

    @Value("${spring.ai.google.genai.chat.model}")
    private String genAiModel;

    @Value("${spring.ai.google.genai.base-url}")
    private String genAiBaseUrl;

    @Value("classpath:/prompts/default_system_prompt.txt")
    private Resource systemPrompt;

    // TODO: 02-1. genAiBaseUrl을 사용하는 googleGenAiChatModel을 살펴보세요.
    // 필요 시 사용자 정의로 빈 구성 가능(baseurl에 대한 설정은 기본 Model에는 없음)
    // @SpringBootApplication에서 GoogleGenAiChatAutoConfiguration 설정 제거 필요
    @Bean
    GoogleGenAiChatModel googleGenAiChatModel() {

        // 1. Low level API 클라이언트 생성
        Client client = Client.builder().apiKey(genAiApiKey)
                .httpOptions(HttpOptions.builder().baseUrl(genAiBaseUrl).build()).build(); //
        // gms
        // .httpOptions(HttpOptions.builder().build()).build(); // 일반

        // 2. 필요한 옵션 재정의
        GoogleGenAiChatOptions options = GoogleGenAiChatOptions.builder().model(genAiModel)
                .temperature(0.7).maxOutputTokens(1000).build();

        // 모델 생성
        GoogleGenAiChatModel model = GoogleGenAiChatModel.builder().genAiClient(client).options(options).build();
        return model;
    }

    // TODO: 04-4. SimpleLoggerAdvisor와 systemPrompt가 적용된 ChatClient.Builder를
    // 살펴보자.
    @Bean
    SimpleLoggerAdvisor simpleLoggerAdvisor() {
        // return SimpleLoggerAdvisor.builder().order(Ordered.LOWEST_PRECEDENCE -
        // 1).build();

        return SimpleLoggerAdvisor.builder()
                .requestToString(this::formatRequest)
                .responseToString(this::formatResponse)
                .order(Ordered.LOWEST_PRECEDENCE - 1)
                .build();
    }

    @Bean
    ChatClient.Builder geminiChatClientBuilder(GoogleGenAiChatModel genAiChatModel, SimpleLoggerAdvisor sLogAdvisor) {
        return ChatClient.builder(genAiChatModel).defaultSystem(systemPrompt)
                .defaultAdvisors(sLogAdvisor);
    }

    @Bean
    ChatClient.Builder openAiChatClientBuilder(OpenAiChatModel openAiChatModel, SimpleLoggerAdvisor sLogAdvisor) {
        return ChatClient.builder(openAiChatModel).defaultSystem(systemPrompt)
                .defaultAdvisors(sLogAdvisor);
    }

    // TODO: 10-4. 10개의 메시지를 활용하도록 ChatMemory 빈을 구성해보자.
    @Bean
    ChatMemory chatMemory(JdbcChatMemoryRepository jdbcChatMemoryRepository) {
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(jdbcChatMemoryRepository).maxMessages(10)
                .build();
    }

    private String formatRequest(ChatClientRequest req) {
        String messages = req.prompt().getInstructions().stream()
                .map(this::formatMessage)
                .collect(Collectors.joining("\n  "));
        return "\n┌── 📤 [AI 요청] ──────────────────────────────────────────\n  " + messages
                + "\n└─────────────────────────────────────────────────────────";
    }

    private String formatMessage(Message msg) {
        return switch (msg.getMessageType()) {
            case SYSTEM -> {
                String text = msg.getText().replace("\n", " ").trim();
                yield "[시스템] " + (text.length() > 45 ? text.substring(0, 45) + "... (생략)" : text);
            }
            case USER -> "[사용자] " + msg.getText();
            case ASSISTANT -> {
                if (msg instanceof AssistantMessage am && am.hasToolCalls()) {
                    String calls = am.getToolCalls().stream()
                            .map(tc -> tc.name() + "(" + tc.arguments() + ")")
                            .collect(Collectors.joining(", "));
                    yield "[AI -> 도구호출 요청] " + calls;
                }
                yield "[AI] " + msg.getText();
            }
            case TOOL -> {
                if (msg instanceof ToolResponseMessage trm) {
                    String results = trm.getResponses().stream()
                            .map(tr -> tr.name() + " => " + tr.responseData())
                            .collect(Collectors.joining(", "));
                    yield "[도구 실행결과] " + results;
                }
                yield "[도구] " + msg.getText();
            }
        };
    }

    private String formatResponse(ChatResponse res) {
        var result = res.getResult();
        var output = result.getOutput();
        var usage = res.getMetadata().getUsage();
        String finish = result.getMetadata().getFinishReason();

        StringBuilder sb = new StringBuilder("\n┌── 📥 [AI 응답] ──────────────────────────────────────────\n");
        sb.append(String.format("  • 상태 : %s (토큰 - 입력:%d, 출력:%d, 합계:%d)\n",
                finish, usage.getPromptTokens(), usage.getCompletionTokens(), usage.getTotalTokens()));

        if (output.hasToolCalls()) {
            String calls = output.getToolCalls().stream()
                    .map(tc -> tc.name() + "(" + tc.arguments() + ")")
                    .collect(Collectors.joining(", "));
            sb.append("  • 도구호출 요청 : ").append(calls);
        } else {
            sb.append("  • 최종 답변 : ").append(output.getText());
        }
        sb.append("\n└─────────────────────────────────────────────────────────");
        return sb.toString();
    }

}
