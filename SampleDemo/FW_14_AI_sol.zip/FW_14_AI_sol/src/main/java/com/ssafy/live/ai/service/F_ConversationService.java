package com.ssafy.live.ai.service;

import java.io.IOException;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.VectorStoreChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class F_ConversationService {
    private final ChatClient chatClient;
    private ChatMemory chatMemory;
    private VectorStore historyVectorStore;

    public F_ConversationService(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        this.chatClient = builder.clone().build();
    }

    @Autowired(required = false)
    public void setChatMemory(ChatMemory chatMemory) {
        this.chatMemory = chatMemory;
    }

    @Autowired(required = false)
    public void setHistoryVectorStore(
            @Qualifier("chatHistoryVectorStore") VectorStore historyVectorStore) {
        this.historyVectorStore = historyVectorStore;
    }

    public String simpleGeneration(String question) {
        return chatClient.prompt()
                .user(question)
                .call()
                .content();
    }

    public String memoryGeneration(String userInput, String conversationId) {
        // TODO: 10-5. ChatMemory를 확인하고 MessageChatMemoryAdvisor를 적용하고 사용해보자.
        return chatClient.prompt().user(userInput) // user 메시지 전달
                .advisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                .call() // model 호출
                .content(); // 응답의 내용을 단순한 문자열로 반환
    }

    public String historyGeneration(String userInput, String conversationId) {
        // TODO: 11-2. VectorStoreChatMemoryAdvisor를 적용하고 사용해보자.
        return chatClient.prompt().user(userInput) // user 메시지 전달
                .advisors(VectorStoreChatMemoryAdvisor.builder(historyVectorStore).defaultTopK(2).build())
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                .call() // model 호출
                .content(); // 응답의 내용을 단순한 문자열로 반환
    }

}
