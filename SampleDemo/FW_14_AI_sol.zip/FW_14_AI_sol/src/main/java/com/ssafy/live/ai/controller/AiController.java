package com.ssafy.live.ai.controller;

import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.live.ai.service.D_MultiModalService;
import com.ssafy.live.ai.service.F_ConversationService;
import com.ssafy.live.ai.service.H_RAGService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/ai")
@RequiredArgsConstructor
@Slf4j
public class AiController {

    private final D_MultiModalService multiModalService;
    private final F_ConversationService conversationService;
    private final H_RAGService ragService;

    @PostMapping(value = "/chat", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> chat(
            @RequestParam String message,
            @RequestParam(defaultValue = "default_user_id") String userId,
            @RequestParam(required = false) MultipartFile file,
            @RequestParam(defaultValue = "false") boolean useRag) {

        try {
            Object result;
            if (file != null && !file.isEmpty()) {
                log.debug("이미지 분석을 위해 MultiModalService 사용 사용자: {}", userId);
                ByteArrayResource resource = new ByteArrayResource(file.getBytes());
                result = multiModalService.chatBotImageDescription(resource, message, userId);
            } else if (useRag) {
                log.debug("지식 검색을 위해 RAGService 사용 사용자: {}", userId);
                SearchRequest searchRequest = SearchRequest.builder()
                        .query(message)
                        .topK(3)
                        .build();
                result = ragService.ragGeneration(message, searchRequest, userId);
            } else {
                log.debug("일반 채팅을 위해 ConversationService를 사용 사용자: {}", userId);
                // 전달받은 userId를 사용하여 대화 맥락 유지
                result = conversationService.historyGeneration(message, userId);
            }
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            log.error("AI 채팅 처리 중 오류 발생", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("요청 처리 중 오류가 발생했습니다: " + e.getMessage());
        }
    }
}
