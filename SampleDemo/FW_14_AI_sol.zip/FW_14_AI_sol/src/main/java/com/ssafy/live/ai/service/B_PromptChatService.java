package com.ssafy.live.ai.service;

import java.io.IOException;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
public class B_PromptChatService {
        private final ChatClient openAiClient;

        // TODO: 04-1. default_penpal_prompt.txt 파일을 Resource로 주입받고 openAiClient에
        // 적용해보자.
        private final Resource systemPrompt;

        public B_PromptChatService(OpenAiChatModel openAi,
                        @Value("classpath:/prompts/default_penpal_prompt.txt") Resource systemPrompt)
                        throws IOException {
                this.systemPrompt = systemPrompt;

                this.openAiClient = ChatClient.builder(openAi)
                                .defaultSystem(spec -> spec.text(systemPrompt).param("language",
                                                "한국어"))
                                .build();
        }

        public String chat(String language, String topic) {
                // 사용자 프롬프트에서도 다시 한번 언어와 관계를 강조합니다.
                String user = "상대방과의 관계: {topic}에게 보낼 따뜻한 안부 편지를 5줄 내외로 작성해줘.";

                // TODO: 04-2. system prompt를 재정의 해보고 user prompt를 추가해서 chat을 진행해보자.
                return openAiClient.prompt()
                                // 시스템 프롬프트에 필요한 모든 파라미터 주입
                                .system(spec -> spec.text(systemPrompt).param("language", language))
                                .user(spec -> spec.text(user).param("topic", topic)) //
                                .advisors(
                                                SimpleLoggerAdvisor.builder().order(Ordered.LOWEST_PRECEDENCE - 1)
                                                                .build())
                                .call().content();
        }
}
