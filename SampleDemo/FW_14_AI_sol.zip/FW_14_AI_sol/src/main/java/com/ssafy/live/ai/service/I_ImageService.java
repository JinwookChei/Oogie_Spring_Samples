package com.ssafy.live.ai.service;

import java.io.File;
import java.io.IOException;

import org.springframework.ai.image.ImageMessage;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class I_ImageService implements G_FileService {

    // OpenAi의 ImageModel은 제공 된다.
    private final OpenAiImageModel imodel;

    @Value("${spring.ai.google.genai.api-key}")
    private String genAiApiKey;

    @Value("${spring.ai.google.genai.base-url}")
    private String genAiBaseUrl;

    // TODO: 15-2. OpenAi Image API를 호출하여 이미지를 생성하는 메서드 작성해보자.
    public File generateOpenAiImageFile(String text, String title) throws IOException {
        ImageMessage iMessage = new ImageMessage(text);
        org.springframework.ai.openai.OpenAiImageOptions iOptions = org.springframework.ai.openai.OpenAiImageOptions.builder()
                .height(1024)
                .width(1024)
                .build();
        // List<ImageMessage> + ImageOption --> ImagePrompt
        ImagePrompt prompt = new ImagePrompt(iMessage, iOptions);
        // ImageResponse > Generation > base64 String
        String base64 = imodel.call(prompt).getResult().getOutput().getB64Json();

        return base64ToImg(base64, title);
    }
}
