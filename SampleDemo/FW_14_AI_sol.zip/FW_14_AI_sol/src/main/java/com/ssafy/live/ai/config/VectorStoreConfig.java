package com.ssafy.live.ai.config;

import org.springframework.ai.openai.OpenAiEmbeddingModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore.MetadataField;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.RedisClient;

@Configuration
@ConditionalOnProperty(name = "spring.redis.enabled", havingValue = "true", matchIfMissing = false)
@Slf4j
public class VectorStoreConfig {

    // TODO: 08-2. VectorStore를 구성해보자.
    @Bean
    RedisClient redisClient() {
        return RedisClient.create("localhost", 6379);
    }

    @Bean
    VectorStore customEmbeddingVector(OpenAiEmbeddingModel eModel, RedisClient redisClient) {
        return RedisVectorStore.builder(redisClient, eModel)
                .initializeSchema(true) // Optional: schema 초기화 여부(default: false)
                .metadataFields( // Optional: filtering을 위한 metadata field 설정
                        MetadataField.tag("category"),
                        MetadataField.numeric("meta_num"),
                        MetadataField.text("meta_txt"))
                .build();
    }

    // TODO: 11-1. Chat History용 저장소를 구성해보자.
    @Bean
    RedisVectorStore chatHistoryVectorStore(OpenAiEmbeddingModel eModel, RedisClient redisClient) {
        // Chat 전용 인덱스
        return RedisVectorStore.builder(redisClient, eModel)
                .indexName("chat-history")
                .prefix("chat:")
                .metadataFields(MetadataField.tag("conversationId"), // 검색에 필요한 ID
                        MetadataField.text("timestamp"), // 전달 시각
                        MetadataField.text("messageType"), // 메시지 타입
                        MetadataField.text("chat_memory_message_type")// Spring AI 내부 보관용 메시지 타입 키 추가
                    ) 
                .initializeSchema(true).build();
    }
}
