package com.ssafy.live.ai.service;

import java.io.File;
import java.io.IOException;

import org.springframework.ai.audio.transcription.TranscriptionModel;
import org.springframework.ai.audio.tts.TextToSpeechModel;
import org.springframework.ai.audio.tts.TextToSpeechPrompt;
import org.springframework.ai.audio.tts.TextToSpeechResponse;
import org.springframework.ai.openai.OpenAiAudioSpeechOptions;
import org.springframework.ai.openai.OpenAiAudioTranscriptionOptions;
import com.openai.models.audio.AudioResponseFormat;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class J_AudioService implements G_FileService {

    private final TextToSpeechModel speechModel;
    private final TranscriptionModel transcriptionModel;

    // TODO: 16-1. OpenAi TTS API를 호출하여 텍스트를 음성으로 변환하는 메서드를 작성해보자.
    public String generateTTS(String text) throws IOException {
        OpenAiAudioSpeechOptions speechOptions = OpenAiAudioSpeechOptions.builder()
                .model("gpt-4o-mini-tts").voice(OpenAiAudioSpeechOptions.Voice.ALLOY)
                .responseFormat(OpenAiAudioSpeechOptions.AudioResponseFormat.MP3).speed(1.0)
                .build();

        TextToSpeechPrompt speechPrompt = new TextToSpeechPrompt(text, speechOptions);
        TextToSpeechResponse response = speechModel.call(speechPrompt);

        byte[] audioData = response.getResult().getOutput();

        File file = toFile(audioData, "tts_output", "mp3");
        return file.getCanonicalPath();
    }

    // TODO: 16-3. OpenAi STT API를 호출하여 음성을 텍스트로 변환하는 메서드를 작성해보자.
    public String generateSTT(Resource audioFile) {
        AudioResponseFormat responseFormat = AudioResponseFormat.VTT;

        OpenAiAudioTranscriptionOptions transcriptionOptions = OpenAiAudioTranscriptionOptions
                .builder().language("ko").temperature(0f).responseFormat(responseFormat).build();

        String result = transcriptionModel.transcribe(audioFile, transcriptionOptions);
        return result;
    }
}
