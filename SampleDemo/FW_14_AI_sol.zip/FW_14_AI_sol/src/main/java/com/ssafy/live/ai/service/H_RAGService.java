package com.ssafy.live.ai.service;
import org.springframework.ai.chat.memory.ChatMemory;



import java.io.IOException;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.VectorStoreChatMemoryAdvisor;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class H_RAGService {

    private final ChatClient chatClient;
    private VectorStore eVectorStore; // embedding vector store: rag용
    private VectorStore hVectorStore; // history vector store: chating 용

    public H_RAGService(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        this.chatClient = builder.clone().build();
    }

    @Autowired(required = false)
    public void setRagVectorStore(@Qualifier("customEmbeddingVector") VectorStore eVectorStore) {
        this.eVectorStore = eVectorStore;
    }

    @Autowired(required = false)
    public void sethVectorStore(
            @Qualifier("chatHistoryVectorStore") VectorStore hVectorStore) {
        this.hVectorStore = hVectorStore;
    }

    public String ragGeneration(String userInput, SearchRequest searchRequest,
            String conversationId) {
        // TODO: 13-2. QuestionAnswerAdvisor가 적용된 chatClient를 구성하고 사용해보자.
        var qaAdvisor = QuestionAnswerAdvisor.builder(eVectorStore).searchRequest(searchRequest).build();
        return chatClient.prompt().user(userInput)
                .advisors(qaAdvisor, VectorStoreChatMemoryAdvisor.builder(hVectorStore).build())
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                .call().content();
    }
}
