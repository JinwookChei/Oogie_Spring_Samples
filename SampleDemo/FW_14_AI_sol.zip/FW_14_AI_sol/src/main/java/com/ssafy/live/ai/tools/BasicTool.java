package com.ssafy.live.ai.tools;

import java.time.LocalDateTime;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BasicTool {

    // TODO: 20-2. 현재 사용자의 시간을 가져오는 @Tool을 구성해보자.
    @Tool(description = "사용자의 timezone에 해당하는 현재의 날짜와 시간 정보를 가져온다.")
    LocalDateTime getCurrentDateTime() {
        log.debug("현재 날짜 요청 Tool 호출");
        return LocalDateTime.now();
    }

    @Tool(description = "사용자가 지정한 특정 도시나 지역의 현재 날씨 상황 및 기온 등의 날씨 상세 정보를 조회하여 반환하는 도구입니다.")
    String getWeather(String city) {
        log.debug("throwProblem");
        throw new RuntimeException("대상 지역을 조회할 수 없습니다.");
    }
}
