package com.ssafy.live.ai.service;

import org.springframework.ai.chat.memory.ChatMemory;

import java.io.IOException;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.vectorstore.VectorStoreChatMemoryAdvisor;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;

@Service
public class D_MultiModalService {
    private final ChatClient chatClient;

    public D_MultiModalService(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        this.chatClient = builder.clone().build();
    }

    private VectorStore historyVectorStore;

    @Autowired(required = false)
    public void setHistoryVectorStore(
            @Qualifier("chatHistoryVectorStore") VectorStore historyVectorStore) {
        this.historyVectorStore = historyVectorStore;
    }

    // TODO: 06-1. image resource를 전달받아서 질문을 처리해보자.
    public String imageDescription(Resource res, String question) {
        MimeType mime = MimeTypeUtils.IMAGE_PNG;
        return chatClient.prompt()
                .user(spec -> spec.media(mime, res).text(question))
                .call()
                .content();
    }

    // ChatBotService를 위해 추가
    public String chatBotImageDescription(Resource res, String question, String conversationId) {
        MimeType mime = MimeTypeUtils.IMAGE_PNG;
        return chatClient.prompt()
                .user(spec -> spec.media(mime, res).text(question))
                .advisors(VectorStoreChatMemoryAdvisor.builder(historyVectorStore).build())
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                .call()
                .content();
    }
}
