package com.ssafy.live.ai.tools;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AlarmTool {
    // TODO: 20-7. 사용자의 요청에 따라 시스템에 알람을 요청하는 Tool을 만들어보자.
    @Tool(description = "사용자가 지정한 특정 날짜나 시간에 맞춰서 컴퓨터 운영체제의 시스템 알람을 설정하고 구동하는 역할을 합니다.")
    void setAlarm(@ToolParam(description = "알람을 울릴 시간") LocalDateTime alarmTime) {
        String osName = System.getProperty("os.name").toLowerCase();
        try {
            setAlarm(alarmTime, osName);
            log.debug("{}에 알람이 설정되었습니다.", alarmTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setAlarm(LocalDateTime alarmTime, String osName) throws IOException, InterruptedException {
        // 현재 시간과 알람 시간 사이의 초 계산
        LocalDateTime now = LocalDateTime.now();
        Duration duration = Duration.between(now, alarmTime);
        long seconds = duration.getSeconds();

        // Mac OS에서의 알람 설정
        String[] macScript = {
                "osascript",
                "-e",
                "do shell script \"sleep " + seconds +
                      " && afplay /System/Library/Sounds/Glass.aiff && osascript -e 'display notification \\\"알람 시간입니다!\\\" with title \\\"알람\\\" sound name \\\"Glass\\\"' &\""
        };
        // Window OS에서의 알람 설정
        String taskName = "AlarmAt" + alarmTime.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String time = alarmTime.format(DateTimeFormatter.ofPattern("HH:mm"));

        String[] windowScript = {
                "cmd.exe",
                "/c",
                "schtasks /create /tn \"" + taskName + "\" /tr \"msg %username% 알람 시간입니다!\" /sc once /st " + time
        };

        if (osName.contains("mac")) {
            Runtime.getRuntime().exec(macScript);
        } else if (osName.contains("win")) {
            Runtime.getRuntime().exec(windowScript);
        } else {
            throw new RuntimeException("Unsupported operating system: " + osName + ". Alarm set for " + alarmTime);
        }
        System.out.println("알람이 " + alarmTime.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분 ss초")) + "에 설정되었습니다");
    }

}
