package com.ssafy.live;

import org.springframework.ai.model.google.genai.autoconfigure.chat.GoogleGenAiChatAutoConfiguration;
import org.springframework.ai.vectorstore.redis.autoconfigure.RedisVectorStoreAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// 자동 환경 설정은 제외시킴 - 각각 재구성 예정
@SpringBootApplication(exclude = {
        RedisVectorStoreAutoConfiguration.class
        , GoogleGenAiChatAutoConfiguration.class
        })
public class FW14AIApplication {

    public static void main(String[] args) {
        SpringApplication.run(FW14AIApplication.class, args);
    }

}
