package com.ssafy.live.ai.filter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ai.chat.observation.ChatModelObservationContext;
import org.springframework.ai.observation.ObservabilityHelper;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import io.micrometer.common.KeyValue;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationFilter;

/**
 * 공홈 제공: https://langfuse.com/integrations/frameworks/spring-ai Spring AI의
 * ChatModel 관찰(Observation) 과정에서 프롬프트(질문)와 컴플리션(응답) 내용을 추출하여 트레이싱 태그로 추가하는 필터
 * 
 * 출력 포멧 수정을 위해 일부 코드 추가
 */
@Component
public class ChatModelCompletionContentObservationFilter implements ObservationFilter {

    @Override
    public Observation.Context map(Observation.Context context) {
        if (!(context instanceof ChatModelObservationContext chatModelObservationContext)) {
            return context;
        }
        var prompts = processPrompts(chatModelObservationContext);
        var completions = processCompletion(chatModelObservationContext);
        chatModelObservationContext.addHighCardinalityKeyValue(new KeyValue() {
            @Override
            public String getKey() {
                return "gen_ai.prompt";
            }

            @Override
            public String getValue() {
                return String.join("\n", prompts);
            }
        });
        chatModelObservationContext.addHighCardinalityKeyValue(new KeyValue() {
            @Override
            public String getKey() {
                return "gen_ai.completion";
            }

            @Override
            public String getValue() {
                return ObservabilityHelper.concatenateStrings(completions);
            }
        });
        return chatModelObservationContext;
    }

    private List<String> processPrompts(ChatModelObservationContext chatModelObservationContext) {
        List<String> prompts = new ArrayList<>();
        var instructions = chatModelObservationContext.getRequest().getInstructions();

        if (!CollectionUtils.isEmpty(instructions)) {
            for (var msg : instructions) {
                String role = msg.getMessageType().name();
                prompts.add("[" + role + "]");
                if (msg instanceof org.springframework.ai.chat.messages.ToolResponseMessage toolMsg) {
                    var toolResponses = toolMsg.getResponses().stream()
                            .map(res -> {
                                return "Tool-ID: " + res.id() + ", Result: " + res.responseData();
                            })
                            .toList();
                    prompts.addAll(toolResponses);
                } else {
                    String text = msg.getText();
                    prompts.add(StringUtils.hasText(text) ? text : "(Empty Content)");
                }
                prompts.add(""); 
            }
        }
        return prompts;
    }

    private List<String> processCompletion(ChatModelObservationContext context) {
        if (context.getResponse() != null && (context.getResponse()).getResults() != null
                && !CollectionUtils.isEmpty((context.getResponse()).getResults())) {

            return !StringUtils.hasText((context.getResponse()).getResult().getOutput().getText()) ? List.of()
                    : (context.getResponse()).getResults().stream()
                            .filter((generation) -> generation.getOutput() != null
                                    && StringUtils.hasText(generation.getOutput().getText()))
                            .map((generation) -> generation.getOutput().getText()).toList();
        } else {
            return List.of();
        }
    }
}


