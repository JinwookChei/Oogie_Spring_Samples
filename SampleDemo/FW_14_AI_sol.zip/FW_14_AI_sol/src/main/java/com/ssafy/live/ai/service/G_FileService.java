package com.ssafy.live.ai.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

public interface G_FileService {
    // TODO: 15-1. byte[] 데이터를 파일로 변환하는 메서드 작성해보자.
    default File toFile(byte[] data, String title, String ext) throws IOException {
        String userHome = System.getProperty("user.home");
        Path outputPath = Paths.get(userHome, "Documents",
                "%s_%s.%s".formatted(title, System.currentTimeMillis(), ext));
        Files.write(outputPath, data);
        return outputPath.toFile();
    }

    default File base64ToImg(String base64, String fileName) throws IOException {
        byte[] decoded = Base64.getDecoder().decode(base64);
        return toFile(decoded, fileName, "png");
    }
}
