package com.ssafy.live.ai.service;

import java.io.IOException;
import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.ToolCallingAdvisor;
import org.springframework.ai.model.tool.ToolCallingManager;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.tool.execution.DefaultToolExecutionExceptionProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ssafy.live.ai.tools.AlarmTool;
import com.ssafy.live.ai.tools.BasicTool;
import com.ssafy.live.ai.tools.CardTool;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class K_ToolService {
    private ChatClient chatClient;
    private final BasicTool bTool;
    private final AlarmTool aTool;
    private final CardTool cTool;

    @Autowired
    void setClientBuilder(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        // TODO: 20-6. tool에서 오류가 발생하는 경우 동작을 중지시키거나 LLM을 통해 해결할 수 있도록 처리해보자.
        var toolCallingManager = ToolCallingManager.builder()
                // true 또는 false 직접 결정!
                .toolExecutionExceptionProcessor(new DefaultToolExecutionExceptionProcessor(true))
                .build();
        this.chatClient = builder.clone()
                .defaultOptions(OpenAiChatOptions.builder().reasoningEffort("none"))
                .defaultAdvisors(ToolCallingAdvisor.builder().toolCallingManager(toolCallingManager).build())
                .build();
    }

    public String simpleGeneration(String question) {
        return chatClient.prompt()
                .user(question)
                .call()
                .content();
    }

    public String toolGeneration(String question) {
        // TODO: 20-3. BasicTool을 활용해보자.
        return chatClient.prompt()
                .user(question)
                .tools(bTool, aTool)

                .call()
                .content();
    }

    public String toolContextGeneration(String question, String cn) {
        // TODO: 20-10. CardTool을 사용하면서 cardNo를 ToolContext로 전달해보자.
        return chatClient.prompt()
                .user(question)
                .tools(cTool)
                .toolContext(Map.of("cardNo", cn))
                .call()
                .content();
    }
}
