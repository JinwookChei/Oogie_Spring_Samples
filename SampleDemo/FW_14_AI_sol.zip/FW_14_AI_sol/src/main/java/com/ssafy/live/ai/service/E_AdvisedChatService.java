package com.ssafy.live.ai.service;

import java.io.IOException;
import java.util.List;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SafeGuardAdvisor;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ssafy.live.ai.advisor.ReReadingAdvisor;

@Service
public class E_AdvisedChatService {
    private final ChatClient chatClient;

    public E_AdvisedChatService(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        this.chatClient = builder.clone().build();
    }

    public String reReadingAdvice(String userInput) {
        // TODO: 07-2. 모델을 성능이 떨어지는 gpt-5.4-mini로 바꾸고 ReReadingAdvisor를 추가해보자.
        return this.chatClient.prompt()
                .advisors(new ReReadingAdvisor(0))
                .options(ChatOptions.builder().model("gpt-5.4-mini"))
                .user(userInput).call().content();
    }

    public String recover(Exception e) {
        return "죄송합니다. 현재 AI 서버가 너무 바빠서 응답을 드릴 수 없습니다.";
    }

    public String safeChat(String userInput) {
        // TODO: 07-4. SafeGuardAdvisor를 설치해보자.
        SafeGuardAdvisor safeGuard = SafeGuardAdvisor.builder().sensitiveWords(List.of("싸탈", "비밀번호", "폭력", "폭탄"))
                .failureResponse("해당 질문은 민감한 컨텐츠로 응답할 수 없습니다.").order(10).build();
        return this.chatClient.prompt()
                .advisors(safeGuard)
                .user(userInput).call().content();
    }

}
