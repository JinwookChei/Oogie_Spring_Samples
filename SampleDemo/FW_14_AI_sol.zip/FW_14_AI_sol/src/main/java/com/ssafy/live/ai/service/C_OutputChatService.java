package com.ssafy.live.ai.service;

import java.io.IOException;
import java.util.List;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;

@Service
public class C_OutputChatService {
    private final ChatClient chatClient;

    public C_OutputChatService(@Qualifier("openAiChatClientBuilder") ChatClient.Builder builder)
            throws IOException {
        this.chatClient = builder.clone().build();
    }

    // TODO: 05-1. 단순 문자열로 반환할 때의 문제점에 대해서 고민해보자.
    public String generateStringJoke(String topic) {
        String user = "{topic} 과 관련된 농담과 해설을 하나만 만들어줘.";

        return chatClient.prompt().user(spec -> spec.text(user).param("topic", topic))
                .call().content();
    }

    public record Joke(String content, String reason) {
    }

    // 저수준: 직접 BeanOutputConverter 활용
    public Joke generateRecordJoke1(String topic) {
        String user = "{topic} 과 관련된 농담과 해설을 하나만 만들어줘. \n {format}";
        BeanOutputConverter<Joke> converter = new BeanOutputConverter<>(Joke.class);

        String response = chatClient.prompt()
                .user(spec -> spec.text(user).param("topic", topic).param("format",
                        converter.getFormat())) // 포맷 지시어 주입
                .call().content();

        return converter.convert(response); // 수동 변환
    }

    public Joke generateRecordJoke2(String topic) {
        String user = "{topic} 과 관련된 농담과 해설을 하나만 만들어줘.";
        // TODO: 05-2. entity를 이용해서 Joke record를 반환해보자.
        return chatClient.prompt().user(spec -> spec.text(user).param("topic", topic))
                .call().entity(Joke.class);
    }

    // TODO: 05-3. {genre}의 영화 3편을 추천받아보자. 이때 영화 제목, 감독, 제작년도, 한줄평을 같이 반환 한다.
    public record MovieInfo(String title, String director, String comment, int openYear) {
    }

    public List<MovieInfo> generageRecommendMovies(String genre) {
        String user = "한줄 평(comment)과 함께 {genre}에 해당하는 영화 3편 추천해줘.";
        return chatClient.prompt().user(spec -> spec.text(user).param("genre", genre))
                .call().entity(new ParameterizedTypeReference<List<MovieInfo>>() {
                });
    }
}
