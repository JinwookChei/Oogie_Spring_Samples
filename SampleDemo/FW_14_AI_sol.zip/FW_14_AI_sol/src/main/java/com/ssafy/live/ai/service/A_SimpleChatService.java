package com.ssafy.live.ai.service;

import java.util.Map;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.stereotype.Service;

@Service
public class A_SimpleChatService {
    private final ChatClient openAiClient;
    private final ChatClient geminiClient;

    public A_SimpleChatService(OpenAiChatModel openAi, GoogleGenAiChatModel gemini) {
        // TODO: 03-1. 각각 다른 defaultSystem을 갖는 ChatClient를 구성해보자.
        // 1. 스프링이 준 빌더를 복제해서 인프라(관측)를 보존하고 엔진만 GPT로 지정
        this.openAiClient = ChatClient.builder(openAi).defaultSystem("당신은 전문 번역가입니다.").build();

        // 2. 똑같이 복제해서 인프라를 보존하고 엔진만 Gemini로 지정
        this.geminiClient = ChatClient.builder(gemini).defaultSystem("당신은 요약 전문가입니다.").build();
    }

    public Map<String, String> handleDocument(String doc) {
        // TODO: 03-2. ChatClient의 옵션들이 재정의 되는 과정과 호출을 살펴보세요.
        String result1 = openAiClient.prompt(doc + "를 처리해줘.")
                .options(org.springframework.ai.openai.OpenAiChatOptions.builder().temperature(1.0)).call().content();
        String result2 = geminiClient.prompt(doc + "를 처리해줘.").system("당신은 한글 동요 작사 전문가입니다.")
                .options(org.springframework.ai.google.genai.GoogleGenAiChatOptions.builder().temperature(2.0)).call()
                .content();
        return Map.of("openai", result1, "gemini", result2);
    }
}
