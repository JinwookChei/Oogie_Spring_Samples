package com.ssafy.live.ai.advisor;

import java.util.Map;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.AdvisorChain;
import org.springframework.ai.chat.client.advisor.api.BaseAdvisor;
import org.springframework.ai.chat.prompt.PromptTemplate;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReReadingAdvisor implements BaseAdvisor {

    private static final String DEFAULT_RE2_ADVISE_TEMPLATE = """
            {re2_input_query}
            Read the question again: {re2_input_query}
            """;

    private int order;

    public ReReadingAdvisor(int order) {
        this.order = order;
    }

    @Override
    public String getName() {
        return this.getClass().getSimpleName();
    }

    @Override
    public int getOrder() {
        return this.order;
    }

    // https://docs.spring.io/spring-ai/reference/1.0/api/advisors.html#_re_reading_re2_advisor
    @Override
    public ChatClientRequest before(ChatClientRequest chatClientRequest,
            AdvisorChain advisorChain) {
        log.debug("{} - {}, context: {}", this.getName(), this.getOrder(), chatClientRequest.context());
        chatClientRequest.context().put("additional", "추가로 전달할 내용이 있다면 추가 가능");
        // TODO: 07-1. userMessage가 1000자 이상이거나 '복잡한'이라는 단어가 들어간다면 rereading 해보자.
        String message = chatClientRequest.prompt().getUserMessage().getText();
        if (message.length() > 1_000 || message.contains("복잡한")) {
            String augmentedUserText = PromptTemplate.builder().template(DEFAULT_RE2_ADVISE_TEMPLATE)
                    .variables(Map.of("re2_input_query",
                            chatClientRequest.prompt().getUserMessage().getText()))
                    .build().render();

            return chatClientRequest.mutate() // ChatClientRequest는 한번 생성되면 내용을 변경할 수 없는 불변 객체
                    .prompt(chatClientRequest.prompt().augmentUserMessage(augmentedUserText))
                    .build();
        } else {
            return chatClientRequest;
        }
    }

    @Override
    public ChatClientResponse after(ChatClientResponse chatClientResponse,
            AdvisorChain advisorChain) {
        // 응답에서는 그대로 넘겨주자.
        log.debug("{} - {}, context: {}", this.getName(), this.getOrder(), chatClientResponse.context());
        return chatClientResponse;
    }
}
