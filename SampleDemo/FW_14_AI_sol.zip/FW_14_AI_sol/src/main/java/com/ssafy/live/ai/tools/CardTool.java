package com.ssafy.live.ai.tools;

import java.util.Optional;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CardTool {
    public record CardInfo(String cardNumber, String type, int remainingLimit) {
    }

    @Tool(description = "내부 API를 이용해서 사용자의 신용카드 정보를 조회한다.", returnDirect = true)
    public CardInfo getCreditCardInfo(ToolContext toolContext) {
        // TODO: 20-9. ToolContext에서 숨겨진 사용자 카드 번호 추출해서 카드 정보를 반환해보자.
        Object cardNo = toolContext.getContext().get("cardNo");
        if (cardNo != null) {
            return secretApi(cardNo);
        } else {
            throw new RuntimeException("card no가 없습니다.");
        }
    }

    private CardInfo secretApi(Object cardNo) {
        log.debug("cartNo: {}", cardNo);
        return new CardInfo("masked", "VIP 골드 카드", 500_0000);
    }
}
