# chat memory repository를 위한 기본 schema - 이미 구성됨.

DROP TABLE IF EXISTS SPRING_AI_CHAT_MEMORY;
CREATE TABLE SPRING_AI_CHAT_MEMORY (
    conversation_id VARCHAR(255) NOT NULL,
    sequence_id BIGINT NOT NULL,
    type VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    metadata JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (conversation_id, sequence_id)
);
