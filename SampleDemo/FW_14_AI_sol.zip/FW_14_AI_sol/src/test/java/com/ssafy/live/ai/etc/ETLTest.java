package com.ssafy.live.ai.etc;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.JsonMetadataGenerator;
import org.springframework.ai.reader.JsonReader;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.reader.pdf.config.PdfDocumentReaderConfig;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class ETLTest {

    @Autowired
    @Qualifier("customEmbeddingVector")
    VectorStore store;

    void clearStore(String category) {
        store.delete("category == '" + category + "'");
    }

    @Value("classpath:rag_data/simpleText.txt")
    Resource simpleText;

    @Test
    void simpleText() throws IOException {
        String category = "SSAFY_LIFE";
        clearStore(category);
        // TODO: 12-2. 단순한 문자열로 된 파일을 처리해보자.

        TextReader textReader = new TextReader(simpleText);

        TokenTextSplitter splitter = TokenTextSplitter.builder().build();
        List<Document> list = splitter.apply(textReader.get());
        list.forEach(doc -> doc.getMetadata().put("category", category));
        store.add(list);

        log.debug("총 {} 건의 {} 데이터 로딩 ", list.size(), category);
    }

    @Value("classpath:rag_data/국민연금공단_기금_포트폴리오_20241130.json")
    Resource simpleJson;

    @Test
    public void simpleJsonReaderTest() throws StreamReadException, DatabindException, IOException {
        // TODO: 12-3. simpleJson 파일을 처리해보자.
        // 이때 meta field로 category=json, meta_num=[json의 year]를 설정한다.
        String category = "국민연금";
        clearStore(category);
        JsonMetadataGenerator gen = jsonMap -> Map.of("category", category, "meta_num", jsonMap.get("year"));

        JsonReader jReader = new JsonReader(simpleJson, gen, "year", "전체 자산(시장가)", "복지 부문", "금융 부문(국내주식)",
                "금융 부문(해외주식)", "금융 부문(국내채권)", "금융 부문(해외채권)", "금융 부문(대체투자)", "금융 부문(단기자금)", "기타 부문");
        List<Document> list = jReader.get();
        store.add(list);

        log.debug("총 {} 건의 {} 데이터 로딩 ", list.size(), category);
    }

    @Value("classpath:rag_data/transcriptionapi.pdf")
    Resource simplePdf;

    @Test
    public void pdfReaderTest() {
        // TODO: 12-4. simplePdf 문서를 읽어서 DB에 저장하자.
        String category = "PDF";
        clearStore(category);
        // 1단계: PDF를 페이지 단위로 1차 청킹
        PagePdfDocumentReader pdfReader = new PagePdfDocumentReader(simplePdf,
                PdfDocumentReaderConfig.builder()
                        .withPageBottomMargin(70)
                        .withPageTopMargin(50) // 페이지의 상단 여백 설정
                        .withPagesPerDocument(1) // 하나의 Document에 포함될 PDF 객체의 페이지 수
                        .build());

        // 2단계: 페이지별 Document를 토큰 단위로 2차 청킹
        TokenTextSplitter splitter = TokenTextSplitter.builder().build();
        List<Document> list = splitter.apply(pdfReader.read());
        list.forEach(doc -> doc.getMetadata().put("category", category));

        store.add(list);

        log.debug("총 {} 건의 {} 데이터 로딩 ", list.size(), category);
    }

}
