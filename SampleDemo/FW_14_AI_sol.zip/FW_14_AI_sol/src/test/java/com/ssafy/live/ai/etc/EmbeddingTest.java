package com.ssafy.live.ai.etc;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.openai.OpenAiEmbeddingModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class EmbeddingTest {

        @Autowired(required = false)
        OpenAiEmbeddingModel emodel;

        @Test
        void beanTest() {
                log.debug("emodel: {}", emodel);
                Assertions.assertNotNull(emodel);
        }

        @Test
        void embeddingTest() {
                // TODO: 08-1. embedding model의 동작을 확인하세요.
                String message = "대한민국의 수도는?";
                EmbeddingResponse res = emodel.embedForResponse(List.of(message));
                var metaData = res.getMetadata();
                log.debug("모델 정보: {}", metaData.getModel());
                var result = res.getResult().getOutput();
                log.debug("차원: {}, {}", result.length, Arrays.toString(Arrays.copyOfRange(result, 0, 10)));
        }

}
