package com.ssafy.live.ai.chat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import com.ssafy.live.ai.service.J_AudioService;
import lombok.extern.slf4j.Slf4j;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

@SpringBootTest
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class I_AudioModelTest {

    @Autowired
    J_AudioService ttsService;

    // 파일 이름 확인
    static String audioFilePath = "/Users/quietjun/Documents/tts_output_1765699866560.mp3";

    // TODO: 16-2. OpenAi TTS API를 호출하여 텍스트를 음성으로 변환하는 테스트 메서드를 작성해보자.
    @Test
    @Order(1)
    public void ttsTest() throws Exception {
        String text = "안녕하세요. SSAFY AI 서비스입니다. 텍스트를 음성으로 변환하는 기능을 테스트하고 있습니다.";
        audioFilePath = ttsService.generateTTS(text);
        log.debug("생성된 오디오 파일 경로: {}", audioFilePath);
    }

    // TODO: 16-3. OpenAi STT API를 호출하여 음성을 텍스트로 변환하는 테스트 메서드를 작성해보자.
    @Test
    @Order(2)
    public void sttTest() throws Exception {
        Resource audioFile = new FileSystemResource(audioFilePath);
        String result = ttsService.generateSTT(audioFile);
        log.debug("Transcription 결과: {}", result);
    }
}
