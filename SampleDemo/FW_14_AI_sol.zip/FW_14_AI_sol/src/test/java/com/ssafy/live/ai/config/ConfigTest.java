package com.ssafy.live.ai.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

// TODO: 01-3. properties 파일의 값들이 자ㄹ설정되었는지 확인하세요.
@Slf4j
@SpringBootTest
public class ConfigTest {

    @Value("${spring.ai.openai.base-url:}")
    private String openAiBaseUrl;

    @Value("${spring.ai.openai.chat.model:}")
    private String openAiChatModel;

    @Value("${spring.ai.openai.embedding.base-url:}")
    private String openAiEmbeddingBaseUrl;

    @Value("${spring.ai.openai.embedding.model:}")
    private String openAiEmbeddingModel;

    @Value("${spring.ai.google.genai.base-url:}")
    private String googleGenAiBaseUrl;

    @Value("${spring.ai.google.genai.chat.model:}")
    private String googleGenAiChatModel;

    @Value("${ssafy.gms.api-key:}")
    private String gmsApiKey;

    @Value("${spring.ai.google.genai.api-key:}")
    private String genaiApiKey;

    @Test
    @DisplayName("수업 환경(GMS) 및 AI 설정 속성값 바인딩 & 출력 테스트")
    void testActivePropertiesOutput() {
        log.info("=========================================================");
        log.info(">>> ACTIVE AI & GMS CONFIGURATION VALUE PROPERTIES <<<");
        log.info("=========================================================");
        log.info("1. spring.ai.openai.base-url: {}", openAiBaseUrl);
        log.info("2. spring.ai.openai.chat.model: {}", openAiChatModel);
        log.info("3. spring.ai.openai.embedding.base-url: {}", openAiEmbeddingBaseUrl);
        log.info("4. spring.ai.openai.embedding.model: {}", openAiEmbeddingModel);
        log.info("5. spring.ai.google.genai.base-url: {}", googleGenAiBaseUrl);
        log.info("6. spring.ai.google.genai.chat.model: {}", googleGenAiChatModel);
        log.info("7. ssafy.gms.api-key: {}", maskKey(gmsApiKey));
        log.info("8. GoogleGenAi Api Key: {}", maskKey(genaiApiKey));
        log.info("=========================================================");
    }

    private String maskKey(String key) {
        if (key == null || key.isEmpty()) {
            return "";
        }
        if (key.length() <= 15) {
            return "***masked***";
        }
        return key.substring(0, 10) + "..." + key.substring(key.length() - 5);
    }
}
