package com.ssafy.live.ai.chat;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.ai.service.A_SimpleChatService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class A_SimpleChatServiceTest {
    // TODO: 03-3. SimpleChatService의 동작을 테스트 해보자.
    @Autowired
    A_SimpleChatService chatService;

    @Test
    void callTest() {
        String text = "I am a boy. You are a girl";
        Map<String, String> result = chatService.handleDocument(text);
        result.forEach((k, v) -> {
            log.debug("{}: {}", k, v);
        });
    }
}
