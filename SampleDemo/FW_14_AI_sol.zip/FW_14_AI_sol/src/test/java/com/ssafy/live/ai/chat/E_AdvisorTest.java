package com.ssafy.live.ai.chat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.ssafy.live.ai.service.E_AdvisedChatService;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class E_AdvisorTest {

    @Autowired
    E_AdvisedChatService service;

    @Test
    void reReadingTest() {
        // TODO: 07-3. ReReadingAdvisor가 개입해서 메시지가 형성되는지 살펴보자.
        String userInput = """
                솔로는 과학 교과서 4페이지, 사회 교과서 20페이지, 역사 교과서 7페이지, 지리 교과서 8페이지를 읽어야 한다.
                솔로는 월요일에 15페이지를 이미 읽었다.
                만약 그가 모든 읽기를 끝내기 위해 4일이 더 있다면, 하루 평균 몇 페이지를 읽어야 할까?
                최종 답안은 정답만 단답식으로 출력해줘.
                 """;

        String content1 = service.reReadingAdvice(userInput);
        String content2 = service.reReadingAdvice("복잡한 문제야. " + userInput);
        log.debug("content(기본): {}", content1);
        log.debug("content(rereading): {}", content2);
    }

    @Test
    void safeGuardTest() {
        // TODO: 07-5. 불건전한 단어가 질문에 포함되면 제외되도록 SafeGuardAdvisor를 만들고 설정해보자.
        String content = service.safeChat("싸탈에 대해 알려줘..");
        log.debug("answer: {}", content);
    }
}
