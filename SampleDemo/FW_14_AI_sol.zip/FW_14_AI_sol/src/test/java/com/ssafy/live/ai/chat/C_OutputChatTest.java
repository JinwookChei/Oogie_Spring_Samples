package com.ssafy.live.ai.chat;

import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.ssafy.live.ai.service.C_OutputChatService;
import com.ssafy.live.ai.service.C_OutputChatService.Joke;
import com.ssafy.live.ai.service.C_OutputChatService.MovieInfo;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class C_OutputChatTest {
    @Autowired
    C_OutputChatService service;

    @Test
    void stringChatTest() {
        String result = service.generateStringJoke("코인");
        log.debug("result: {}", result);
    }

    @Test
    void recordChat1Test() {
        Joke result = service.generateRecordJoke1("코인");
        log.debug("content: {}", result.content());
        log.debug("reason: {}", result.reason());
    }

    @Test
    void recordChat2Test() {
        Joke result = service.generateRecordJoke2("코인");
        log.debug("content: {}", result.content());
        log.debug("reason: {}", result.reason());
    }

    // TODO: 05-4. generageRecommendMovies를 사용해보자.
    @Test
    void movieTest() {
        List<MovieInfo> result = service.generageRecommendMovies("SF");
        Assertions.assertEquals(3, result.size());
        result.forEach(System.out::println);
    }
}
