package com.ssafy.live.ai.chat;

import java.net.MalformedURLException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import com.ssafy.live.ai.service.D_MultiModalService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class D_MultiModalTest {

    @Autowired
    D_MultiModalService service;

    // TODO: 06-2. image resource를 전달하고 설명을 들어보자.
    @Test
    void objectDectionTest() throws MalformedURLException {
        // local resource
        Resource res = new ClassPathResource("/static/sample.png");
        String question = "이 그림에  대해서 설명해줘.";
        log.debug("result: {}", service.imageDescription(res, question));
        // remote resource
        res = new UrlResource("https://cdn-sprites.flaticon.com/families/7_detail.jpg");
        question = "이 그림에는 몇 개의 아이콘이 있어?";
        log.debug("result: {}", service.imageDescription(res, question));
    }

}
