package com.ssafy.live.ai.chat;

import java.io.File;
import java.io.IOException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.ssafy.live.ai.service.I_ImageService;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class H_ImageModelTest {

    @Autowired
    I_ImageService iService;

    @Test
    void openAiTest() throws IOException {
        // TODO: 15-3. OpenAi Image API를 호출하여 이미지를 생성하는 테스트 메서드를 작성해보자.
        String text = "강아지와 고양이가 서로 꼬리잡기 놀이하는 그림을 사진 처럼 그려줘.";
        File generated = iService.generateOpenAiImageFile(text, "openai");
        log.debug("file: {}", generated);
        Assertions.assertTrue(generated.exists());
    }
}
