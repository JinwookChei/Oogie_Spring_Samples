package com.ssafy.live.ai.etc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;
import org.springframework.ai.openai.OpenAiEmbeddingModel;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter.Expression;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class VectorStoreTest {

        @Autowired(required = false)
        @Qualifier("customEmbeddingVector")
        VectorStore vStore;

        @Autowired(required = false)
        OpenAiEmbeddingModel emodel;

        @Test
        void beanTest() {
                log.debug("vstore: {}", vStore);
                Assertions.assertNotNull(vStore);
        }

        // TODO: 08-4. 테스트를 위해서 VectorStore에 데이터를 구성하는 과정을 살펴보자.
        private static List<Document> docs;

        @BeforeEach
        void setUp() {
                log.info("테스트 데이터 로드 시작");
                docs = generateSampleDocuments();
                // VectorStore에 추가
                vStore.add(docs);
                log.info("테스트 데이터 {}개 로드 완료", docs.size());
        }

        // @AfterEach
        void tearDown() {
                log.info("테스트 데이터 삭제 시작");
                // 모든 테스트 Document 삭제
                List<String> ids = docs.stream()
                                .map(Document::getId)
                                .toList();
                vStore.delete(ids);
                log.info("테스트 데이터 {}개 삭제 완료", ids.size());
        }

        /**
         * 유사도 검사를 위한 샘플 Document 생성
         */
        public List<Document> generateSampleDocuments() {
                List<Document> documents = new ArrayList<>();

                // Document 1: 자바 프로그래밍
                documents.add(new Document(
                                "doc_001",
                                "Java는 객체지향 프로그래밍 언어로, 플랫폼 독립적인 특성을 가지고 있습니다. JVM 위에서 실행되며 엔터프라이즈 애플리케이션 개발에 널리 사용됩니다.",
                                Map.of(
                                                "category", "programming",
                                                "meta_num", 1,
                                                "meta_txt", "java basics")));

                // Document 2: 스프링 프레임워크
                documents.add(new Document(
                                "doc_002",
                                "Spring Framework는 Java 기반의 엔터프라이즈 애플리케이션 개발을 위한 프레임워크입니다. 의존성 주입과 AOP를 핵심 기능으로 제공합니다.",
                                Map.of(
                                                "category", "framework",
                                                "meta_num", 2,
                                                "meta_txt", "spring framework")));

                // Document 3: 데이터베이스
                documents.add(new Document(
                                "doc_003",
                                "Redis는 인메모리 데이터 구조 저장소로, 키-값 데이터베이스로 사용됩니다. 캐싱, 세션 관리, 실시간 분석 등에 활용됩니다.",
                                Map.of(
                                                "category", "database",
                                                "meta_num", 3,
                                                "meta_txt", "redis nosql")));

                // Document 4: 머신러닝
                documents.add(new Document(
                                "doc_004",
                                "머신러닝은 인공지능의 한 분야로, 데이터로부터 패턴을 학습하여 예측이나 결정을 수행합니다. 지도학습, 비지도학습, 강화학습으로 구분됩니다.",
                                Map.of(
                                                "category", "ai",
                                                "meta_num", 4,
                                                "meta_txt", "machine learning")));

                // Document 5: 웹 개발
                documents.add(new Document(
                                "doc_005",
                                "웹 개발은 프론트엔드와 백엔드로 나뉩니다. HTML, CSS, JavaScript는 프론트엔드 기술이고, Java, Python, Node.js는 백엔드 기술입니다.",
                                Map.of(
                                                "category", "web",
                                                "meta_num", 5,
                                                "meta_txt", "web development")));

                // Document 6: 클라우드 컴퓨팅
                documents.add(new Document(
                                "doc_006",
                                "클라우드 컴퓨팅은 인터넷을 통해 컴퓨팅 리소스를 제공하는 서비스입니다. AWS, Azure, GCP가 대표적인 클라우드 서비스 제공자입니다.",
                                Map.of(
                                                "category", "cloud",
                                                "meta_num", 6,
                                                "meta_txt", "cloud computing")));

                // Document 7: 보안
                documents.add(new Document(
                                "doc_007",
                                "애플리케이션 보안은 소프트웨어의 취약점을 방지하고 데이터를 보호합니다. SQL 인젝션, XSS, CSRF 같은 공격으로부터 시스템을 보호해야 합니다.",
                                Map.of(
                                                "category", "security",
                                                "meta_num", 7,
                                                "meta_txt", "application security")));

                // Document 8: 데이터 구조
                documents.add(new Document(
                                "doc_008",
                                "데이터 구조는 데이터를 효율적으로 저장하고 관리하는 방법입니다. 배열, 링크드 리스트, 스택, 큐, 트리, 그래프 등이 있습니다.",
                                Map.of(
                                                "category", "programming",
                                                "meta_num", 8,
                                                "meta_txt", "data structures")));

                // Document 9: API 설계
                documents.add(new Document(
                                "doc_009",
                                "RESTful API는 HTTP 프로토콜을 기반으로 하는 API 설계 방식입니다. 자원 중심의 URI 설계와 HTTP 메서드를 활용하여 직관적인 인터페이스를 제공합니다.",
                                Map.of(
                                                "category", "web",
                                                "meta_num", 9,
                                                "meta_txt", "rest api")));

                // Document 10: 벡터 데이터베이스
                documents.add(new Document(
                                "doc_010",
                                "벡터 데이터베이스는 임베딩 벡터를 저장하고 유사도 검색을 수행하는 특화된 데이터베이스입니다. AI 애플리케이션에서 시맨틱 검색에 활용됩니다.",
                                Map.of(
                                                "category", "database",
                                                "meta_num", 10,
                                                "meta_txt", "vector database")));

                return documents;
        }

        @Test
        void simularitySearchSimple() {
                String query = "Java 프로그래밍 언어에 대해 알려주세요";
                // TODO: 09-1. query와 유사한 데이터를 3개 찾아보세요.
                var searchRequest = SearchRequest.builder()
                                .query(query).topK(3).similarityThreshold(0.6)
                                .build();
                List<Document> results = vStore.similaritySearch(searchRequest);
                printInfo(results);
        }

        @Test
        void simularitySearchUseFilter1() {
                // TODO: 09-2.FilterExpression을 사용하는 검색 방법을 살펴보자.
                FilterExpressionBuilder builder = new FilterExpressionBuilder();
                Expression expression = builder.and(
                                builder.eq("category", "database"),
                                builder.and(
                                                builder.in("meta_txt", "redis", "vector"),
                                                builder.gte("meta_num", 3)))
                                .build();

                SearchRequest filterRequest = SearchRequest.builder()
                                .query("데이터베이스 저장소")
                                .topK(3)
                                .similarityThreshold(0.5)
                                .filterExpression(expression)
                                .build();

                List<Document> results = vStore.similaritySearch(filterRequest);
                printInfo(results);
        }

        @Test
        void simularitySearchUseFilter2() {
                // TODO: 09-3. 문자열로 Filter를 구성하는 검색 방법을 살펴보자.
                String strExpression = "category=='database' && meta_txt in ['redis','vector'] && meta_num>=3";

                SearchRequest filterRequest = SearchRequest.builder()
                                .query("데이터베이스 저장소")
                                .topK(3)
                                .similarityThreshold(0.5)
                                .filterExpression(strExpression)
                                .build();

                List<Document> results = vStore.similaritySearch(filterRequest);
                printInfo(results);
        }

        private void printInfo(List<Document> results) {
                log.debug("===  검색 결과: {} ===", results.size());
                results.forEach(doc -> {
                        log.debug("text {} ", doc.getText());
                        log.debug("metadata: {}", doc.getMetadata());
                        log.debug("score: {}", doc.getScore());
                });
        }
}
