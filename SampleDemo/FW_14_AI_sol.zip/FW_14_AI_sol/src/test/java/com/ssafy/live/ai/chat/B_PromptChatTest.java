package com.ssafy.live.ai.chat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.ai.service.B_PromptChatService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class B_PromptChatTest {
    // TODO: 04-3. PromptChatService를 테스트 해보자.
    @Autowired
    B_PromptChatService promptService;

    @Test
    void promptTest() {
        String result1 = promptService.chat("한국어", "부모님");
        log.debug("result1 : {}", result1);

        String result2 = promptService.chat("영어", "친구");
        log.debug("result1 : {}", result2);
    }
}
