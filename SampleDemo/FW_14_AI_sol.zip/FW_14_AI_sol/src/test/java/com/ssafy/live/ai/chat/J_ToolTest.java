package com.ssafy.live.ai.chat;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.ai.service.K_ToolService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class J_ToolTest {
    @Autowired
    K_ToolService service;

    // TODO: 20-1. LLM의 Pretrained한 특성 한계를 알아보자.
    @Test
    void llmLimit() {
        String answer1 = service.simpleGeneration("너는 언제까지 학습한 모델이야?");
        String tomorrow = service.simpleGeneration("내일이 몇 일이지?");
        String weather = service.simpleGeneration("오늘 서울 날씨 어때?");
        log.debug("answer: {}", answer1);
        log.debug("내일 날짜: {}: ", tomorrow);
        log.debug("오늘 서울 날씨: {}: ", weather);
    }

    // TODO: 20-4. Tool이 적용된 채팅 결과를 확인해보자.
    @Test
    void basicToolTest1() {
        String tomorrow = service.toolGeneration("내일이 몇 일이지?");
        log.debug("내일 날짜: {}: ", tomorrow);
    }

    // TODO: 20-5. Tool이 적용된 채팅 결과를 확인해보자.
    @Test
    void basicToolTest2() {

        service.toolGeneration("서울 지역의 현재 날씨는?");

    }

    // TODO: 20-8. Tool이 적용된 채팅 결과를 확인해보자.
    @Test
    void alarmToolTest() {
        String userInput = "1분 후로 알람 설정해주고 언제 울릴껀지 알려줘.";
        String result = service.toolGeneration(userInput);
        log.debug("알람 예정시각: {}: ", result);
    }

    // TODO: 20-11. ToolContext로 전달된 정보를 처리해보자..
    @Test
    void creditCardToolTest() {
        // 실제로는 사용자의 프롬프트가 아니라, 서버의 SecurityContext나 세션에서 꺼낸 민감 정보라고 가정
        String cn = "1234";
        String result = service.toolContextGeneration("내 카드 한도랑 정보 알려줘.", cn);
        log.debug("카드 정보: {}", result);
    }
}
