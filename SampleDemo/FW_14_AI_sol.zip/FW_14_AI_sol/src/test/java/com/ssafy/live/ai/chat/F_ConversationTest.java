package com.ssafy.live.ai.chat;

import org.junit.jupiter.api.Test;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.ai.service.F_ConversationService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class F_ConversationTest {

    @Autowired
    F_ConversationService service;

    @Test
    // TODO: 10-1. 대화 맥락 유지의 필요성에 대해 고민해보자.
    public void messageNoChatMemoryAdvisorTest() throws Exception {
        String user1 = "내 이름은 홍길동이야.";
        Object answer1 = service.simpleGeneration(user1);
        String user2 = "내 이름으로 3행시 지어줘.";
        Object answer2 = service.simpleGeneration(user2);
        String user3 = "나랑 이름이 같은 사람 중 유명인 1사람만 이야기해줘.";
        Object answer3 = service.simpleGeneration(user3);
        log.debug("answer1: {}", answer1);
        log.debug("answer2: {}", answer2);
        log.debug("answer3: {}", answer3);
    }

    @Test
    // TODO: 10-6. ChatMemory를 이용해서 대화 맥락이 유지되는지 살펴보자.
    public void messageChatMemoryAdvisorTest() throws Exception {
        String user1 = "내 이름은 홍길동이야.";
        Object answer1 = service.memoryGeneration(user1, "ssafy");
        String user2 = "내 이름으로 3행시 지어줘.";
        Object answer2 = service.memoryGeneration(user2, "ssafy");
        String user3 = "나랑 이름이 같은 사람 중 유명인 1사람만 이야기해줘.";
        Object answer3 = service.memoryGeneration(user3, "ssafy");
        log.debug("answer1: {}", answer1);
        log.debug("answer2: {}", answer2);
        log.debug("answer3: {}", answer3);
    }

    @Autowired(required = false)
    @Qualifier("chatHistoryVectorStore")
    VectorStore historyVectorStore;

    @Test
    // TODO: 11-3. ChatHistory를 통해서 대화 맥락이 유지되는지 살펴보자.
    public void historyChatMemoryAdvisorTest() throws Exception {
        String user1 = "내 이름은 홍길동이야.";
        Object answer1 = service.historyGeneration(user1, "ssafy");
        String user2 = "내 이름으로 3행시 지어줘.";
        Object answer2 = service.historyGeneration(user2, "ssafy");
        String user3 = "나랑 이름이 같은 사람 중 유명인 1사람만 이야기해줘.";
        Object answer3 = service.historyGeneration(user3, "ssafy");
        log.debug("answer1: {}", answer1);
        log.debug("answer2: {}", answer2);
        log.debug("answer3: {}", answer3);

        // 대화가 끝나면 conversation id 기준으로 삭제 처리
        historyVectorStore.delete("conversationId == 'ssafy'");
    }

}
