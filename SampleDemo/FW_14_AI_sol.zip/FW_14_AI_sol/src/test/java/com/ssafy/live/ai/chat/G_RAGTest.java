package com.ssafy.live.ai.chat;

import org.junit.jupiter.api.Test;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.ssafy.live.ai.service.H_RAGService;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class G_RAGTest {
    // TODO: 13-3. ragGeneration을 이용해서 사용자 질문을 처리해보자.
    @Autowired
    H_RAGService service;

    @Test
    void ssafyLifeTest() {
        String userInput = "임의 결석을 4회 했을 때 수강생의 운명은 어떻게 될까?";
        var searchRequest = SearchRequest.builder().query(userInput)
                .topK(3)
                .filterExpression("category=='SSAFY_LIFE'")
                .similarityThreshold(0.5).build();
        String result1 = service.ragGeneration(userInput, searchRequest, "default_user_id");
        log.debug("과연 그는: {}", result1);
    }

    @Test
    void 국민연금_Test() {
        String userInput =
                "context에 전달된 국민연금 공단의 기금 포트폴리오를 분석해서 금융 부문 해외 주식이 240894이상인 경우를 알려줘. 이에 따라 개인 투자자는 어떤 투자 방식을 취해야 할까?";
        var searchRequest = SearchRequest.builder().query(userInput).topK(3)
                .filterExpression("category=='국민연금'")
                .similarityThreshold(0.5).build();
        String result1 = service.ragGeneration(userInput, searchRequest, "default_user_id");
        log.debug("금융 부문 해외 주식 현황: {}", result1);
    }

    @Test
    void pdfTest() {
        String userInput = "한줄 요약해줘..";
        var searchRequest =
                SearchRequest.builder().query(userInput).topK(3).filterExpression("category=='PDF'")
                        .similarityThreshold(0).build();
        String result1 = service.ragGeneration(userInput, searchRequest, "default_user_id");
        log.debug("내용 요약: {}", result1);
    }
}
