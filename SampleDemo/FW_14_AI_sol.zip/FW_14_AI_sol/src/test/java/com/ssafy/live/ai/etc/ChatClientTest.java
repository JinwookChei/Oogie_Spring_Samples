package com.ssafy.live.ai.etc;


import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class ChatClientTest {
    // TODO: 02-2. 구성된 ChatModel들을 확인하세요.
    @Autowired
    @Qualifier("openAiChatModel")
    private ChatModel openAiChatModel;

    @Autowired
    @Qualifier("googleGenAiChatModel")
    private ChatModel genAiChatModel;

    @Test
    @DisplayName("OpenAiChatClient 빈 주입 테스트")
    void openAiChatClientInjectionTest() {
        assertNotNull(openAiChatModel);
        printModelInfo(openAiChatModel);
    }

    @Test
    @DisplayName("Gemini ChatClient 빈 주입 테스트")
    void genAiChatClientInjectionTest() {
        assertNotNull(genAiChatModel);
        printModelInfo(genAiChatModel);
    }

    // TODO: 02-3. Model의 ChatOptions구성과 간단한 채팅 결과를 확인하세요.
    private void printModelInfo(ChatModel model) {
        log.debug("======= Model Information =======");
        log.debug("Model Implementation: {}", model.getClass().getSimpleName());

        var options = model.getOptions();
        if (options != null) {
            log.debug("Model Name: {}", options.getModel());
            log.debug("Temperature: {}", options.getTemperature());
            log.debug("Full Options: {}", options);
        }
        log.debug("=================================");

        var response = model.call(new Prompt("안녕? 너는 어떤 모델이야?"));
        var gen = response.getResult();
        log.debug("response: {}", gen.getOutput().getText());
    }
}
