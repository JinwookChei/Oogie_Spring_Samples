package com.ssafy.live.restcontroller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

// TODO: 02-1. MemberController의 내용을 @RestController를 구성해보자.
//  대표 경로는 /api/v1/public/members으로 처리한다. REST API는 세션 관리를 하지 않는다.
@RestController
@RequestMapping("/api/v1/public/members")
@RequiredArgsConstructor
@Slf4j
// @CrossOrigin
@Tag(name = "MemberRestController", description = "회원 가입을 위한 기능 제공")
public class MemberRestController {

    private final MemberService mService;

    // @PostMapping
    private Map<String, Object> registMember_step1(@ModelAttribute Member member) {
        mService.registMember(member);
        return Map.of("member", member);
    }

    @PostMapping(version = "v1")
    @Operation(summary = "회원 가입", description = "회원 가입을 처리한다. 회원 정보는 json 문자열로 전달받는다.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "회원 가입 성공"),
            @ApiResponse(responseCode = "500", description = "회원 가입 실패(서버오류)"),
    })
    private ResponseEntity<?> registMember_step2(@RequestBody Member member) {
        mService.registMember(member);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("member", member));
    }

    @GetMapping(path = "/check-email", version = "v1")
    private ResponseEntity<?> checkEmailDuplicate(@RequestParam String email) {
        Member selected = mService.selectDetail(email);
        return ResponseEntity.status(HttpStatus.OK).body(Map.of("canUse", selected == null));
    }
}

