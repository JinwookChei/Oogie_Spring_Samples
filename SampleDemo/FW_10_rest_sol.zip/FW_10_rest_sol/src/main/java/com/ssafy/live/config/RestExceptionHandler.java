package com.ssafy.live.config;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ssafy.live.restcontroller.MemberRestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
// TODO: 02-2. RestController에서 발생하는 예외를 ProblemDetail 객체로 반환해보자.
@RestControllerAdvice(basePackageClasses = MemberRestController.class)
public class RestExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleRestException(Exception e) {
        log.error("[@RestController에서 발생한 오류] ", e);
        // 모든 API 예외는 여기서 JSON(ProblemDetail)으로 응답
        return ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    }
}
