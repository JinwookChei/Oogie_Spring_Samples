<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">
img {
 width: 100%
}
</style>
</head>
<body>
    <%@ include file="/WEB-INF/views/fragments/header.jsp"%>
    <div class="container">
        <img src="https://httpcats.com/999.jpg" alt="999" />
    </div>
    <%@ include file="/WEB-INF/views/fragments/footer.jsp"%>
</body>
</html>
