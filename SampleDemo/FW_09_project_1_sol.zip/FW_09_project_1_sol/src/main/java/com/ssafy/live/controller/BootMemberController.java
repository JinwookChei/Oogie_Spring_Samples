package com.ssafy.live.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/member")
@RequiredArgsConstructor
@Slf4j
public class BootMemberController {

    private final MemberService mService;

    @GetMapping("/regist-member-form")
    private String registMemberForm() {
        return "member/member-regist-form";
    }

    @GetMapping("/login-form")
    private String loginForm() {
        return "member/login-form";
    }

    @PostMapping("/regist-member")
    private String registMember(@ModelAttribute Member member, Model model, RedirectAttributes redirs) {
        try {
            mService.registMember(member);
            String message = "등록되었습니다. 로그인 후 사용해주세요.";
            redirs.addFlashAttribute("alertMsg", message);
            return "redirect:/";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", e.getMessage());
            return "member/member-regist-form";
        }
    }

    @PostMapping("/login")
    private String login(@RequestParam String email, @RequestParam String password, HttpSession session,
            Model model) {
        try {
            Member member = mService.login(email, password);
            session.setAttribute("loginUser", member);

            return "redirect:/";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("alertMsg", e.getMessage());
            return "member/login-form";
        }
    }

    @GetMapping("/logout")
    private String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/checkEmail")
    @ResponseBody
    private Map<String, ?> checkEmailDuplicate(@RequestParam String email) {
        try {
            Member selected = mService.selectDetail(email);
            return Map.of("canUse", selected == null);
        } catch (Exception e) {
            log.error("check email fial: {}", e.getMessage(), e);
            return Map.of("error", e.getMessage());
        }
    }
}
