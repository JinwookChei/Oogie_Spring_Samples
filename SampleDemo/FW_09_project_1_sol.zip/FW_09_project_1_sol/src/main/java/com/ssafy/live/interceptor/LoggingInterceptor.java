package com.ssafy.live.interceptor;

import java.util.Arrays;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
// TODO: 06-1. HandlerInterceptor를 구현해서 요청 기존의 LoggingFilter를 대체해보자.
public class LoggingInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        log.debug("##요청 경로: {}, 요청 방식: {}##", request.getRequestURI(), request.getMethod());
        log.debug("요청 파라미터 분석");
        request.getParameterMap().forEach((k, v) -> {
            log.debug(" - name: {}, value: {}", k, Arrays.toString(v));
        });

        request.setAttribute("start", System.currentTimeMillis());
        return HandlerInterceptor.super.preHandle(request, response, handler);
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        long start = (Long) request.getAttribute("start");
        log.debug("요청 URL: {}, handler 처리 시간: {}", request.getRequestURL(), System.currentTimeMillis() - start);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        long start = (Long) request.getAttribute("start");
        log.debug("요청 URL: {}, 최종 처리 시간: {}", request.getRequestURL(), System.currentTimeMillis() - start);
    }
}
