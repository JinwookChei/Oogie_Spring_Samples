package com.ssafy.live.controller;

import java.io.IOException;
import java.util.Map;

import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.BasicMemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

// TODO: 05-3. @Controller로 변경하고 service의 case에 해당하는 handler 메서드를 작성하세요.
@WebServlet("/member")
@RequiredArgsConstructor
public class MemberController extends HttpServlet implements ControllerHelper {
    private static final long serialVersionUID = 1L;

    private final BasicMemberService mService;

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = getActionParameter(request, response);
        switch (action) {
            case "regist-member-form" -> forward(request, response, "/member/member-regist-form.jsp");
            case "login-form" -> forward(request, response, "/member/login-form.jsp");
            case "regist-member" -> registMember(request, response);
            case "login" -> login(request, response);
            case "logout" -> logout(request, response);
            case "checkEmail" -> checkEmailDuplicate(request, response);
            default -> response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    private void registMember(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            Member member = new Member(name, email, password);
            mService.registMember(member);
            String message = "등록되었습니다. 로그인 후 사용해주세요.";
            HttpSession session = request.getSession();
            session.setAttribute("alertMsg", message);
            redirect(request, response, "/");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", e.getMessage());
            forward(request, response, "/member/member-regist-form.jsp");
        }
    }

    private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String pass = request.getParameter("password");
        try {
            Member member = mService.login(email, pass);
            request.getSession().setAttribute("loginUser", member);

            redirect(request, response, "/");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("alertMsg", e.getMessage());
            forward(request, response, "/member/login-form.jsp");
        }
    }

    private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getSession().invalidate();
        redirect(request, response, "/");
    }

    private void checkEmailDuplicate(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String email = request.getParameter("email");
            Member selected = mService.selectDetail(email);
            Map<String, Boolean> result = Map.of("canUse", selected == null);
            toJSON(result, response);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
    }
}
