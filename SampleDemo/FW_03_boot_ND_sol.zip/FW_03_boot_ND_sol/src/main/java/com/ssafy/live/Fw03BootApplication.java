package com.ssafy.live;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fw03BootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Fw03BootApplication.class, args);
    }

}
