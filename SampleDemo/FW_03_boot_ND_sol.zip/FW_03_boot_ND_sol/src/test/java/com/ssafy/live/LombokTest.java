package com.ssafy.live;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.model.dto.Member;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class LombokTest {

    @Test
    public void makeMemberTest() {
        Assertions.assertThrows(NullPointerException.class, () -> Member.builder().build());
        Member member = Member.builder().password("1234").name("hong").email("hong@ssafy.com").build();
        log.debug("member: {}", member);
    }

}
