package com.ssafy.live;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.model.dao.MemberDao;
import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.service.MemberService;

@SpringBootTest
class Fw03BootApplicationTests {
    private final Logger log = LoggerFactory.getLogger(Fw03BootApplicationTests.class);

    @Value("${service.manager.id}")
    private String id;

    @Value("${service.manager.age}")
    private int age;

    @Value("${service.roles}")
    private List<String> roles;

    @Test
    void valueTest() {
        Assertions.assertEquals(30, age);
        Assertions.assertEquals(List.of("admin", "manager", "guest"), roles);
        log.debug("id: {}", id);
    }

    @Autowired
    MemberService mService;

    @Autowired
    MemberDao mDao;

    @Test
    void beanCreationTest() {
        Assertions.assertNotNull(mService);
        Assertions.assertNotNull(mDao);
    }

    @Test
    void serviceTest() throws SQLException {
        Member m = mService.login("admin@ssafy.com", "1234");
        Assertions.assertNotNull(m);
        Assertions.assertEquals("관리자", m.getName());
    }

}
