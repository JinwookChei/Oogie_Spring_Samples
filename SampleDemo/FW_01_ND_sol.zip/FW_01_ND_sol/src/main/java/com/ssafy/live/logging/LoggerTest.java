package com.ssafy.live.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LoggerTest {
    private final static Logger log = LoggerFactory.getLogger(LoggerTest.class);
    
    public static void main(String[] args) {
        log.trace("trace: {}", "trace level");
        log.debug("debug: {}", "debug level");
        log.info("info: {}", "info level");
        log.warn("warn: {}", "warn level");
        log.error("error: {}", "error level");
    }
}
