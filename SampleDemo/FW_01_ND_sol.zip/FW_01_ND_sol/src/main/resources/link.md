# 자주 사용되는 링크 모음

## maven 관련 링크

- mvn repository: https://mvnrepository.com/

## Spring 관련 링크

 - Spring Projects: https://spring.io/projects

## logback 관련 링크

- 기본 설정 파일 : https://logback.qos.ch/manual/configuration.html#automaticConf
- RollingFileAppender: https://logback.qos.ch/manual/appenders.html#RollingFileAppender

## junit 관련 링크

- junit: https://junit.org/junit5

