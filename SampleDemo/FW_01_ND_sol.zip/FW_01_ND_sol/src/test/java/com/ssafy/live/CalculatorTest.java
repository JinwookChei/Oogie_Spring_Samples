package com.ssafy.live;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ssafy.live.calc.Calculator;

public class CalculatorTest {

    private static Logger log = LoggerFactory.getLogger(CalculatorTest.class);

    private Calculator calc;

    @BeforeEach
    public void setup() {
        log.debug("@BeforeEach - 개별 테스트에서 필요한 리소스 초기화");
        calc = new Calculator();
    }

    @AfterEach
    public void cleanup() {
        log.debug("@AfterEach - 개별 테스트에서 초기화했던 리소스 정리");
    }

    @BeforeAll
    public static void setupAll() {
        log.debug("@BeforeAll - 모든 테스트에서 공통적으로 사용할 리소스 초기화");
    }

    @AfterAll
    public static void cleanupAll() {
        log.debug("@AfterAll - @BeforeAll에서 초기화했던 리소스 정리");
    }

    @Test
    @DisplayName("두수를더해서나오는합을검증: ex) 1 + 2 = 3")
    public void 두수를더해서나오는합을검증() {
        // given: 테스트에 필요한 입력 데이터 준비
        int a = 10;
        int b = 20;

        // when: 테스트 대상 메서드 실행
        int result = calc.add(a, b);

        // then: 실행 결과 검증
        Assertions.assertEquals(30, result);
    }

    @Test
    @DisplayName("나눗셈에 대한 연산 결과 검증: 100 / 2 = 50")
    public void divideTest() {
        // given: 테스트에 필요한 입력 데이터 준비
        int a = 100;
        int b = 2;

        // when: 테스트 대상 메서드 실행
        int result = calc.divide(a, b);

        // then: 실행 결과 검증
        Assertions.assertEquals(50, result);
    }

    @Test
    @DisplayName("같은 객체를 참조하는가? 같은 내용인가")
    public void assertEqualsSameTest() {
        // given: 비교할 문자열 데이터 준비
        String literal = "Hello";

        // when: 서로 다른 두 String 객체 생성
        String str1 = new String(literal);
        String str2 = new String(literal);

        // then: 값(equals)은 같고 참조(same)는 다른지 검증
        assertEquals(str1, str2);
        assertNotSame(str1, str2);
    }

    @Test
    @DisplayName("배열의 내용이 같은가?")
    public void assertArray() {
        // given: 원본 문자열 준비
        String str = "HelloJUnit";

        // when: 각각 문자 배열로 변환
        char[] chars1 = str.toCharArray();
        char[] chars2 = str.toCharArray();

        // then: 배열 참조(equals)는 다르고 배열의 요소 내용(arrayEquals)은 같은지 검증
        assertNotEquals(chars1, chars2);
        assertArrayEquals(chars1, chars2);
    }

}
